﻿
// Dialog-Based CalculatorDlg.h: 头文件
//

#pragma once
enum STATE {LHS_START,LHS_SIGNED,LHS_DOTTED,LHS_SIGNED_DOTTED };

// CDialogBasedCalculatorDlg 对话框
class CDialogBasedCalculatorDlg : public CDialogEx
{
// 构造
public:
	CDialogBasedCalculatorDlg(CWnd* pParent = nullptr);	// 标准构造函数

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOGBASED_CALCULATOR_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
	CFont m_fontButton;
	CBrush m_brushButton;
	STATE m_state;
	void OnAddDigit(TCHAR c);

	protected:
	HICON m_hIcon;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	//CBrush m_brush;
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton5();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton11();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton12();
	afx_msg void OnEnChangeEdit2();
	afx_msg void OnBnClickedButton7();
	CString caloutput;
	afx_msg void OnEnChangeCal();
	CMFCButton bt0;
	CMFCButton bt3;
	CMFCButton bt2;
	CMFCButton bt1;
	CMFCButton bt6;
	CMFCButton bt5;
	CMFCButton bt4;
	CMFCButton bt9;
	CMFCButton bt8;
	CMFCButton bt7;
	CEdit CALEDIT;
	afx_msg void OnBnClickedButton0();
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButton6();
	afx_msg void OnBnClickedButton8();
	afx_msg void OnBnClickedButton9();
	afx_msg void OnBnClickedNeg();
	afx_msg void OnEnChangeEdit1();
	afx_msg void OnBnClickedPi();
	CString hisoutput;
	afx_msg void OnBnClickedDot();
	afx_msg void OnBnClickedPlus();
	afx_msg void OnBnClickedEqual();
	CString history;
	CString history2;
	afx_msg void OnEnChangeHistory2();
	afx_msg void OnEnChangeHistory();
	CButton minus;
	afx_msg void OnBnClickedMinus();
	afx_msg void OnBnClickedX();
	afx_msg void OnBnClickeddiv();
};
