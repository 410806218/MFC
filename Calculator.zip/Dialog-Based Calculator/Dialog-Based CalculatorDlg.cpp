﻿
// Dialog-Based CalculatorDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "Dialog-Based Calculator.h"
#include "Dialog-Based CalculatorDlg.h"
#include "afxdialogex.h"
#include  <string> 
#ifdef _DEBUG
#define new DEBUG_NEW
#endif
float equal = 0;
int check = 0;

// CDialogBasedCalculatorDlg 对话框



CDialogBasedCalculatorDlg::CDialogBasedCalculatorDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOGBASED_CALCULATOR_DIALOG, pParent)
	, caloutput(_T("0"))
	,m_state(LHS_START)
	, hisoutput(_T(""))
	, history(_T(""))
	, history2(_T(""))
{

	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDialogBasedCalculatorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_CAL, caloutput);
	DDX_Control(pDX, IDC_BUTTON0, bt0);
	DDX_Control(pDX, IDC_BUTTON3, bt3);
	DDX_Control(pDX, IDC_BUTTON2, bt2);
	DDX_Control(pDX, IDC_BUTTON1, bt1);
	DDX_Control(pDX, IDC_BUTTON6, bt6);
	DDX_Control(pDX, IDC_BUTTON5, bt5);
	DDX_Control(pDX, IDC_BUTTON4, bt4);
	DDX_Control(pDX, IDC_BUTTON9, bt9);
	DDX_Control(pDX, IDC_BUTTON8, bt8);
	DDX_Control(pDX, IDC_BUTTON7, bt7);
	DDX_Control(pDX, IDC_CAL, CALEDIT);
	DDX_Text(pDX, IDC_History1, hisoutput);
	DDX_Text(pDX, IDC_HISTORY, history);

	DDX_Control(pDX, IDC_MINUS, minus);
}

BEGIN_MESSAGE_MAP(CDialogBasedCalculatorDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON5, &CDialogBasedCalculatorDlg::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON2, &CDialogBasedCalculatorDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CDialogBasedCalculatorDlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON7, &CDialogBasedCalculatorDlg::OnBnClickedButton7)
	ON_EN_CHANGE(IDC_CAL, &CDialogBasedCalculatorDlg::OnEnChangeCal)
	ON_BN_CLICKED(IDC_BUTTON0, &CDialogBasedCalculatorDlg::OnBnClickedButton0)
	ON_BN_CLICKED(IDC_BUTTON1, &CDialogBasedCalculatorDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON4, &CDialogBasedCalculatorDlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON6, &CDialogBasedCalculatorDlg::OnBnClickedButton6)
	ON_BN_CLICKED(IDC_BUTTON8, &CDialogBasedCalculatorDlg::OnBnClickedButton8)
	ON_BN_CLICKED(IDC_BUTTON9, &CDialogBasedCalculatorDlg::OnBnClickedButton9)
	ON_BN_CLICKED(IDC_NEG, &CDialogBasedCalculatorDlg::OnBnClickedNeg)
	//ON_EN_CHANGE(IDC_EDIT1, &CDialogBasedCalculatorDlg::OnEnChangeEdit1)
	ON_BN_CLICKED(IDC_PI, &CDialogBasedCalculatorDlg::OnBnClickedPi)
	ON_BN_CLICKED(IDC_DOT, &CDialogBasedCalculatorDlg::OnBnClickedDot)
	ON_BN_CLICKED(IDC_PLUS, &CDialogBasedCalculatorDlg::OnBnClickedPlus)
	ON_BN_CLICKED(IDC_EQUAL, &CDialogBasedCalculatorDlg::OnBnClickedEqual)
	ON_EN_CHANGE(IDC_HISTORY2, &CDialogBasedCalculatorDlg::OnEnChangeHistory2)
	ON_EN_CHANGE(IDC_HISTORY, &CDialogBasedCalculatorDlg::OnEnChangeHistory)
	ON_BN_CLICKED(IDC_MINUS, &CDialogBasedCalculatorDlg::OnBnClickedMinus)
	ON_BN_CLICKED(IDC_X, &CDialogBasedCalculatorDlg::OnBnClickedX)
	ON_BN_CLICKED(IDC_div, &CDialogBasedCalculatorDlg::OnBnClickeddiv)
END_MESSAGE_MAP()


// CDialogBasedCalculatorDlg 消息处理程序

BOOL CDialogBasedCalculatorDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标
	
	SetWindowLong(GetSafeHwnd(), GWL_EXSTYLE, GetWindowLong(GetSafeHwnd(), GWL_EXSTYLE) | WS_EX_LAYERED);
	SetLayeredWindowAttributes(0, 250, LWA_ALPHA);
	// TODO: 在此添加额外的初始化代码
	m_fontButton.CreateFont(32, 0, 0, 0, FW_BOLD, 0, 0, 0, DEFAULT_CHARSET,
		0, 0, 0, 0, _T("Microsoft Sans Serif"));
	

	bt0.SetFont(&m_fontButton);
	bt0.EnableWindowsTheming(FALSE);
	bt0.SetFaceColor(RGB(64, 93, 100));
	bt0.SetTextColor(RGB(220, 220, 220));
	bt0.m_bGrayDisabled = TRUE;

	bt1.SetFont(&m_fontButton);
	bt1.EnableWindowsTheming(FALSE);
	bt1.SetFaceColor(RGB(64, 93, 100));
	bt1.SetTextColor(RGB(220, 220, 220));
	bt1.m_bGrayDisabled = TRUE;

	bt2.SetFont(&m_fontButton);
	bt2.EnableWindowsTheming(FALSE);
	bt2.SetFaceColor(RGB(64, 93, 100));
	bt2.SetTextColor(RGB(220, 220, 220));
	bt2.m_bGrayDisabled = TRUE;

	bt3.SetFont(&m_fontButton);
	bt3.EnableWindowsTheming(FALSE);
	bt3.SetFaceColor(RGB(64, 93, 100));
	bt3.SetTextColor(RGB(220, 220, 220));
	bt3.m_bGrayDisabled = TRUE;

	CALEDIT.SetFont(&m_fontButton);
	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CDialogBasedCalculatorDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CDialogBasedCalculatorDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CDialogBasedCalculatorDlg::OnEnChangeCal()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
}
void CDialogBasedCalculatorDlg::OnBnClickedButton0()
{
	// TODO: 在此添加控件通知处理程序代码
	UpdateData();
	if (check == 1) {
		caloutput = "0";
		check = 0;
		m_state = LHS_START;
	}
	int len = caloutput.GetLength();
	if (len < 18)
	{
		if (len == 1 && caloutput == "0")
		{
			caloutput = L"0";
		}
		else
		{
			caloutput += L"0";
		}
	}

	UpdateData(FALSE);
}

void CDialogBasedCalculatorDlg::OnBnClickedButton1()
{
	UpdateData();
	if (check == 1) {
		caloutput = "0";
		check = 0;
		m_state = LHS_START;
	}
	int len = caloutput.GetLength();
	if (len < 18)
	{
		if (len == 1 && caloutput == "0")
		{
			caloutput = L"1";
		}
		else
		{
			caloutput += L"1";
		}
	}
	
	UpdateData(FALSE);
}
void CDialogBasedCalculatorDlg::OnBnClickedButton2()
{
	UpdateData();
	if (check == 1) {
		caloutput = "0";
		check = 0;
		m_state = LHS_START;
	}
	int len = caloutput.GetLength();
	if (len < 18)
	{
		if (len == 1 && caloutput == "0")
		{
			caloutput = L"2";
		}
		else
		{
			caloutput += L"2";
		}
	}
	UpdateData(FALSE);
}
void CDialogBasedCalculatorDlg::OnBnClickedButton3()
{
	UpdateData();
	if (check == 1) {
		caloutput = "0";
		check = 0;
		m_state = LHS_START;
	}
	int len = caloutput.GetLength();
	if (len < 18)
	{
		if (len == 1 && caloutput == "0")
		{
			caloutput = L"3";
		}
		else
		{
			caloutput += L"3";
		}
	}
	UpdateData(FALSE);
}
void CDialogBasedCalculatorDlg::OnBnClickedButton4()
{
	UpdateData();
	if (check == 1) {
		caloutput = "0";
		check = 0;
		m_state = LHS_START;
	}
	int len = caloutput.GetLength();
	if (len < 18)
	{
		if (len == 1 && caloutput == "0")
		{
			caloutput = L"4";
		}
		else
		{
			caloutput += L"4";
		}
	}
	UpdateData(FALSE);
}
void CDialogBasedCalculatorDlg::OnBnClickedButton5()
{
	UpdateData();
	if (check == 1) {
		caloutput = "0";
		check = 0;
		m_state = LHS_START;
	}
	int len = caloutput.GetLength();
	if (len < 18)
	{
		if (len == 1 && caloutput == "0")
		{
			caloutput = L"5";
		}
		else
		{
			caloutput += L"5";
		}
	}
	UpdateData(FALSE);
}
void CDialogBasedCalculatorDlg::OnBnClickedButton6()
{
	UpdateData();
	if (check == 1) {
		caloutput = "0";
		check = 0;
		m_state = LHS_START;
	}
	int len = caloutput.GetLength();
	if (len < 18)
	{
		if (len == 1 && caloutput == "0")
		{
			caloutput = L"6";
		}
		else
		{
			caloutput += L"6";
		}
	}
	UpdateData(FALSE);
}
void CDialogBasedCalculatorDlg::OnBnClickedButton7()
{
	UpdateData();
	if (check == 1) {
		caloutput = "0";
		check = 0;
		m_state = LHS_START;
	}
	int len = caloutput.GetLength();
	if (len < 18)
	{
		if (len == 1 && caloutput == "0")
		{
			caloutput = L"7";
		}
		else
		{
			caloutput += L"7";
		}
	}
	UpdateData(FALSE);
}
void CDialogBasedCalculatorDlg::OnBnClickedButton8()
{
	UpdateData();
	if (check == 1) {
		caloutput = "0";
		check = 0;
		m_state = LHS_START;
	}
	int len = caloutput.GetLength();
	if (len < 18)
	{
		if (len == 1 && caloutput == "0")
		{
			caloutput = L"8";
		}
		else
		{
			caloutput += L"8";
		}
	}
	UpdateData(FALSE);
}
void CDialogBasedCalculatorDlg::OnBnClickedButton9()
{
	UpdateData();
	if (check == 1) {
		caloutput = "0";
		check = 0;
		m_state = LHS_START; m_state = LHS_START;
	}
	int len = caloutput.GetLength();
	if (len < 18)
	{
		if (len == 1 && caloutput == "0")
		{
			caloutput = L"9";
		}
		else
		{
			caloutput += L"9";
		}
	}
	UpdateData(FALSE);
}


void CDialogBasedCalculatorDlg::OnBnClickedNeg()
{
	// TODO: 在此添加控件通知处理程序代码
	// 1. 將所有controls之資料匯入指定之變數中
	UpdateData();
	// 2. 根據目前狀態決定處理方式
	switch (m_state) {
	case LHS_START:
		if (caloutput != L"0") {
			caloutput = L"-" + caloutput;
			m_state = LHS_SIGNED;
		}
		break;
	case LHS_SIGNED:
		caloutput = caloutput.Right(caloutput.GetLength() - 1);
		m_state = LHS_START;
		break;
	case LHS_DOTTED:
		caloutput = L"-" + caloutput;
		m_state = LHS_SIGNED_DOTTED;
		break;
	case LHS_SIGNED_DOTTED:
		caloutput = caloutput.Right(caloutput.GetLength() - 1);
		m_state = LHS_DOTTED;
		break;
	}

	// 3. 將新的變數值匯入對應之controls中
	UpdateData(FALSE);

}


void CDialogBasedCalculatorDlg::OnEnChangeEdit1()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
}


void CDialogBasedCalculatorDlg::OnBnClickedPi()
{
	// TODO: 在此添加控件通知处理程序代码
}


void CDialogBasedCalculatorDlg::OnBnClickedDot()
{
	// 1. 將所有controls之資料匯入指定之變數中
	UpdateData();

	int len = caloutput.GetLength();
	// 2. 根據目前狀態決定處理方式
	switch (m_state) {
	case LHS_START:
		if (len > 16) break;
		caloutput += L'.';
		m_state = LHS_DOTTED;
		break;
	case LHS_SIGNED:
		if (len > 17) break;
		caloutput += L'.';
		m_state = LHS_SIGNED_DOTTED;
		break;
		// disallowed in the following state
	case LHS_DOTTED:
	case LHS_SIGNED_DOTTED:
		break;
	}

	// 3. 將新的變數值匯入對應之controls中
	UpdateData(FALSE);
}


void CDialogBasedCalculatorDlg::OnBnClickedPlus()
{
	// 1. 將所有controls之資料匯入指定之變數中
	UpdateData();

	int len = caloutput.GetLength();
	// 2. 根據目前狀態決定處理方式
	switch (m_state) {
	case LHS_START:
		if (caloutput == "0") {
			break;
		}
		if (hisoutput == "") {
			hisoutput += caloutput;
			equal += _ttof(caloutput);
			caloutput.Format(_T("%lf"), equal);
			check = 1;
			history.Format(_T("%lf"), equal);
			hisoutput += L'+';

		}
		else {
			if (hisoutput.Right(1) == '-')
			{
				if (check == 1) {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '+';
				}
				else {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '-';
					hisoutput += caloutput;
					equal -= _ttof(caloutput);
					caloutput.Format(_T("%lf"), equal);
					check = 1;
					history.Format(_T("%lf"), equal);
					hisoutput += '+';
				}

			}
			else if (hisoutput.Right(1) == '*') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '+';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
						hisoutput += caloutput;
						equal *= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '+';
					}

				}
			}
			else if (hisoutput.Right(1) == '/') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '+';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
						hisoutput += caloutput;
						if (caloutput == '0') {
							hisoutput = "";
							caloutput = "";
						}
						equal /= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '+';
					}

				}
			}
			else if (hisoutput.Right(1) == '+' && check == 0)
			{
				hisoutput += caloutput;
				equal += _ttof(caloutput);
				caloutput.Format(_T("%lf"), equal);
				check = 1;
				history.Format(_T("%lf"), equal);
				hisoutput += L'+';
			}
		}
		m_state = LHS_START;
		break;
	case LHS_SIGNED:
		if (caloutput == "0") {
			break;
		}
		if (hisoutput == "") {
			hisoutput += caloutput;
			equal += _ttof(caloutput);
			caloutput.Format(_T("%lf"), equal);
			check = 1;
			history.Format(_T("%lf"), equal);
			hisoutput += L'+';

		}
		else {
			if (hisoutput.Right(1) == '-')
			{
				if (check == 1) {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '+';
				}
				else {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '-';
					hisoutput += caloutput;
					equal -= _ttof(caloutput);
					caloutput.Format(_T("%lf"), equal);
					check = 1;
					history.Format(_T("%lf"), equal);
					hisoutput += '+';
				}

			}
			else if (hisoutput.Right(1) == '*') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '+';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
						hisoutput += caloutput;
						equal *= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '+';
					}

				}
			}
			else if (hisoutput.Right(1) == '/') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '+';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
						hisoutput += caloutput;
						if (caloutput == '0') {
							hisoutput = "";
							caloutput = "";
						}
						equal /= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '+';
					}

				}
			}
			else if (hisoutput.Right(1) == '+' && check == 0)
			{
				hisoutput += caloutput;
				equal += _ttof(caloutput);
				caloutput.Format(_T("%lf"), equal);
				check = 1;
				history.Format(_T("%lf"), equal);
				hisoutput += L'+';
			}
		}
		break;
		// disallowed in the following state
	case LHS_DOTTED:
		if (caloutput == "0") {
			break;
		}
		if (hisoutput == "") {
			hisoutput += caloutput;
			equal += _ttof(caloutput);
			caloutput.Format(_T("%lf"), equal);
			check = 1;
			history.Format(_T("%lf"), equal);
			hisoutput += L'+';

		}
		else {
			if (hisoutput.Right(1) == '-')
			{
				if (check == 1) {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '+';
				}
				else {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '-';
					hisoutput += caloutput;
					equal -= _ttof(caloutput);
					caloutput.Format(_T("%lf"), equal);
					check = 1;
					history.Format(_T("%lf"), equal);
					hisoutput += '+';
				}

			}
			else if (hisoutput.Right(1) == '*') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '+';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
						hisoutput += caloutput;
						equal *= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '+';
					}

				}
			}
			else if (hisoutput.Right(1) == '/') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '+';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
						hisoutput += caloutput;
						if (caloutput == '0') {
							hisoutput = "";
							caloutput = "";
						}
						equal /= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '+';
					}

				}
			}
			else if (hisoutput.Right(1) == '+' && check == 0)
			{
				hisoutput += caloutput;
				equal += _ttof(caloutput);
				caloutput.Format(_T("%lf"), equal);
				check = 1;
				history.Format(_T("%lf"), equal);
				hisoutput += L'+';
			}
		}
		break;
	case LHS_SIGNED_DOTTED:
		if (caloutput == "0") {
			break;
		}
		if (hisoutput == "") {
			hisoutput += caloutput;
			equal += _ttof(caloutput);
			caloutput.Format(_T("%lf"), equal);
			check = 1;
			history.Format(_T("%lf"), equal);
			hisoutput += L'+';

		}
		else {
			if (hisoutput.Right(1) == '-')
			{
				if (check == 1) {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '+';
				}
				else {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '-';
					hisoutput += caloutput;
					equal -= _ttof(caloutput);
					caloutput.Format(_T("%lf"), equal);
					check = 1;
					history.Format(_T("%lf"), equal);
					hisoutput += '+';
				}

			}
			else if (hisoutput.Right(1) == '*') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '+';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
						hisoutput += caloutput;
						equal *= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '+';
					}

				}
			}
			else if (hisoutput.Right(1) == '/') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '+';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
						hisoutput += caloutput;
						if (caloutput == '0') {
							hisoutput = "";
							caloutput = "";
						}
						equal /= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '+';
					}

				}
			}
			else if (hisoutput.Right(1) == '+' && check == 0)
			{
				hisoutput += caloutput;
				equal += _ttof(caloutput);
				caloutput.Format(_T("%lf"), equal);
				check = 1;
				history.Format(_T("%lf"), equal);
				hisoutput += L'+';
			}
		}
		break;
	}

	// 3. 將新的變數值匯入對應之controls中
	UpdateData(FALSE);
}


void CDialogBasedCalculatorDlg::OnBnClickedEqual()
{
	UpdateData();
	int len =hisoutput.GetLength();
	if (len < 1 )
	{
		hisoutput += caloutput;
		UpdateData(FALSE);
	}
	
	if (hisoutput.Right(1) == '+' && check == 0)
	{
		hisoutput += caloutput;
		equal += _ttof(caloutput);
		caloutput.Format(_T("%lf"), equal);
		check = 1;
		history.Format(_T("%lf"), equal);
		
	}
	else if (hisoutput.Right(1) == '-' && check == 0) {
		equal= equal- _ttof(caloutput);
		history.Format(_T("%lf"), equal);
	}
	else if (hisoutput.Right(1) == '*' && check == 0) {
		equal = equal * _ttof(caloutput);
		history.Format(_T("%lf"), equal);
	}
	else if (hisoutput.Right(1) == '/' && check == 0) {
		if (caloutput == '0') {
			hisoutput = "";
			caloutput = "";
		}
		equal = equal / _ttof(caloutput);
		history.Format(_T("%lf"), equal);
	
	}
	hisoutput = "";
	caloutput.Format(_T("%lf"), equal);
	equal = 0;
	
	

	check = 1;
	UpdateData(FALSE);
}


void CDialogBasedCalculatorDlg::OnEnChangeHistory2()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
}


void CDialogBasedCalculatorDlg::OnEnChangeHistory()
{
	// TODO:  如果该控件是 RICHEDIT 控件，它将不
	// 发送此通知，除非重写 CDialogEx::OnInitDialog()
	// 函数并调用 CRichEditCtrl().SetEventMask()，
	// 同时将 ENM_CHANGE 标志“或”运算到掩码中。

	// TODO:  在此添加控件通知处理程序代码
}


void CDialogBasedCalculatorDlg::OnBnClickedMinus()
{
	// 1. 將所有controls之資料匯入指定之變數中
	UpdateData();

	int len = caloutput.GetLength();

	// 2. 根據目前狀態決定處理方式
	switch (m_state) {
	case LHS_START:
		if (caloutput == "0") {
			break;
		}
		if (hisoutput == "") {
			hisoutput += caloutput;
			equal += _ttof(caloutput);
			caloutput.Format(_T("%lf"), equal);
			check = 1;
			history.Format(_T("%lf"), equal);
			hisoutput += L'-';

		}
		else {
			if (hisoutput.Right(1) == '+')
			{
				if (check == 1) {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '-';
				}
				else {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '+';
					hisoutput += caloutput;
					equal += _ttof(caloutput);
					caloutput.Format(_T("%lf"), equal);
					check = 1;
					history.Format(_T("%lf"), equal);
					hisoutput += '-';
				}

			}
			else if (hisoutput.Right(1) == '*') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
						hisoutput += caloutput;
						equal *= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '-';
					}

				}
			}
			else if (hisoutput.Right(1) == '/') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
						hisoutput += caloutput;
						if (caloutput == '0') {
							hisoutput = "";
							caloutput = "";
						}
						equal /= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '-';
					}

				}
			}
			else if (hisoutput.Right(1) == '-' && check == 0)
			{
				hisoutput += caloutput;
				equal -= _ttof(caloutput);
				caloutput.Format(_T("%lf"), equal);
				check = 1;
				history.Format(_T("%lf"), equal);
				hisoutput += L'-';
			}
		}
		m_state = LHS_START;
		break;
	case LHS_SIGNED:
		if (caloutput == "0") {
			break;
		}
		if (hisoutput == "") {
			hisoutput += caloutput;
			equal += _ttof(caloutput);
			caloutput.Format(_T("%lf"), equal);
			check = 1;
			history.Format(_T("%lf"), equal);
			hisoutput += L'-';

		}
		else {
			if (hisoutput.Right(1) == '+')
			{
				if (check == 1) {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '-';
				}
				else {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '+';
					hisoutput += caloutput;
					equal += _ttof(caloutput);
					caloutput.Format(_T("%lf"), equal);
					check = 1;
					history.Format(_T("%lf"), equal);
					hisoutput += '-';
				}

			}
			else if (hisoutput.Right(1) == '*') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
						hisoutput += caloutput;
						equal *= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '-';
					}

				}
			}
			else if (hisoutput.Right(1) == '/') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
						hisoutput += caloutput;
						if (caloutput == '0') {
							hisoutput = "";
							caloutput = "";
						}
						equal /= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '-';
					}

				}
			}
			else if (hisoutput.Right(1) == '-' && check == 0)
			{
				hisoutput += caloutput;
				equal -= _ttof(caloutput);
				caloutput.Format(_T("%lf"), equal);
				check = 1;
				history.Format(_T("%lf"), equal);
				hisoutput += L'-';
			}
		}
		m_state = LHS_SIGNED;
		break;
		// disallowed in the following state
	case LHS_DOTTED:
		if (caloutput == "0") {
			break;
		}
		if (hisoutput == "") {
			hisoutput += caloutput;
			equal += _ttof(caloutput);
			caloutput.Format(_T("%lf"), equal);
			check = 1;
			history.Format(_T("%lf"), equal);
			hisoutput += L'-';

		}
		else {
			if (hisoutput.Right(1) == '+')
			{
				if (check == 1) {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '-';
				}
				else {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '+';
					hisoutput += caloutput;
					equal += _ttof(caloutput);
					caloutput.Format(_T("%lf"), equal);
					check = 1;
					history.Format(_T("%lf"), equal);
					hisoutput += '-';
				}

			}
			else if (hisoutput.Right(1) == '*') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
						hisoutput += caloutput;
						equal *= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '-';
					}

				}
			}
			else if (hisoutput.Right(1) == '/') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
						hisoutput += caloutput;
						if (caloutput == '0') {
							hisoutput = "";
							caloutput = "";
						}
						equal /= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '-';
					}

				}
			}
			else if (hisoutput.Right(1) == '-' && check == 0)
			{
				hisoutput += caloutput;
				equal -= _ttof(caloutput);
				caloutput.Format(_T("%lf"), equal);
				check = 1;
				history.Format(_T("%lf"), equal);
				hisoutput += L'-';
			}
		}		if (caloutput == "0") {
			break;
		}
		if (hisoutput == "") {
			hisoutput += caloutput;
			equal += _ttof(caloutput);
			caloutput.Format(_T("%lf"), equal);
			check = 1;
			history.Format(_T("%lf"), equal);
			hisoutput += L'+';

		}
		else {
			if (hisoutput.Right(1) == '+')
			{
				if (check == 1) {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '-';
				}
				else {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '+';
					hisoutput += caloutput;
					equal += _ttof(caloutput);
					caloutput.Format(_T("%lf"), equal);
					check = 1;
					history.Format(_T("%lf"), equal);
					hisoutput += '-';
				}

			}
			else if (hisoutput.Right(1) == '*') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
						hisoutput += caloutput;
						equal *= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '-';
					}

				}
			}
			else if (hisoutput.Right(1) == '/') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
						hisoutput += caloutput;
						if (caloutput == '0') {
							hisoutput = "";
							caloutput = "";
						}
						equal /= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '-';
					}

				}
			}
			else if (hisoutput.Right(1) == '-' && check == 0)
			{
				hisoutput += caloutput;
				equal -= _ttof(caloutput);
				caloutput.Format(_T("%lf"), equal);
				check = 1;
				history.Format(_T("%lf"), equal);
				hisoutput += L'-';
			}
		}
		m_state = LHS_DOTTED;
		break;
	case LHS_SIGNED_DOTTED:
		if (caloutput == "0") {
			break;
		}
		if (hisoutput == "") {
			hisoutput += caloutput;
			equal += _ttof(caloutput);
			caloutput.Format(_T("%lf"), equal);
			check = 1;
			history.Format(_T("%lf"), equal);
			hisoutput += L'-';

		}
		else {
			if (hisoutput.Right(1) == '+')
			{
				if (check == 1) {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '-';
				}
				else {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '+';
					hisoutput += caloutput;
					equal += _ttof(caloutput);
					caloutput.Format(_T("%lf"), equal);
					check = 1;
					history.Format(_T("%lf"), equal);
					hisoutput += '-';
				}

			}
			else if (hisoutput.Right(1) == '*') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
						hisoutput += caloutput;
						equal *= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '-';
					}

				}
			}
			else if (hisoutput.Right(1) == '/') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
						hisoutput += caloutput;
						if (caloutput == '0') {
							hisoutput = "";
							caloutput = "";
						}
						equal /= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '-';
					}

				}
			}
			else if (hisoutput.Right(1) == '-' && check == 0)
			{
				hisoutput += caloutput;
				equal -= _ttof(caloutput);
				caloutput.Format(_T("%lf"), equal);
				check = 1;
				history.Format(_T("%lf"), equal);
				hisoutput += L'-';
			}
		}
		m_state = LHS_SIGNED_DOTTED;
		break;
	}
	UpdateData(FALSE);
}


void CDialogBasedCalculatorDlg::OnBnClickedX()
{
		// 1. 將所有controls之資料匯入指定之變數中
	UpdateData();

	int len = caloutput.GetLength();

	// 2. 根據目前狀態決定處理方式
	switch (m_state) {
	case LHS_START:
		if (caloutput == "0") {
			break;
		}
		if (hisoutput == "") {
			hisoutput += caloutput;
			equal += _ttof(caloutput);
			caloutput.Format(_T("%lf"), equal);
			check = 1;
			history.Format(_T("%lf"), equal);
			hisoutput += L'*';
			
		}
		else {
			
			if (hisoutput.Right(1) == '+')
			{
				if (check == 1) {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '*';
				}
				else {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '+';
					hisoutput += caloutput;
					equal += _ttof(caloutput);
					caloutput.Format(_T("%lf"), equal);
					check = 1;
					history.Format(_T("%lf"), equal);
					hisoutput += '*';
				}
	
			}
			else if (hisoutput.Right(1) == '-') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
						hisoutput += caloutput;
						equal -= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '*';
					}

				}
			}
			else if (hisoutput.Right(1) == '/') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
						hisoutput += caloutput;
						if (caloutput == '0') {
							hisoutput = "";
							caloutput = "";
						}
						equal /= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '*';
					}

				}
			}
			else if (hisoutput.Right(1)  == '*'&&check==0)
			{
				hisoutput += caloutput;
				equal *= _ttof(caloutput);
				caloutput.Format(_T("%lf"), equal);
				check = 1;
				history.Format(_T("%lf"), equal);
				hisoutput += L'*';
				}				
		}
		
		m_state = LHS_START;
		break;
	case LHS_SIGNED:
		if (caloutput == "0") {
			break;
		}
		if (hisoutput == "") {
			hisoutput += caloutput;
			equal += _ttof(caloutput);
			caloutput.Format(_T("%lf"), equal);
			check = 1;
			history.Format(_T("%lf"), equal);
			hisoutput += L'*';

		}
		else {

			if (hisoutput.Right(1) == '+')
			{
				if (check == 1) {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '*';
				}
				else {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '+';
					hisoutput += caloutput;
					equal += _ttof(caloutput);
					caloutput.Format(_T("%lf"), equal);
					check = 1;
					history.Format(_T("%lf"), equal);
					hisoutput += '*';
				}

			}
			else if (hisoutput.Right(1) == '-') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
						hisoutput += caloutput;
						equal -= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '*';
					}

				}
			}
			else if (hisoutput.Right(1) == '/') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
						hisoutput += caloutput;
						if (caloutput == '0') {
							hisoutput = "";
							caloutput = "";
						}
						equal /= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '*';
					}

				}
			}
			else if (hisoutput.Right(1) == '*' && check == 0)
			{
				hisoutput += caloutput;
				equal *= _ttof(caloutput);
				caloutput.Format(_T("%lf"), equal);
				check = 1;
				history.Format(_T("%lf"), equal);
				hisoutput += L'*';
			}
		}
		m_state = LHS_START;
		break;
		// disallowed in the following state
	case LHS_DOTTED:
		if (caloutput == "0") {
			break;
		}
		if (hisoutput == "") {
			hisoutput += caloutput;
			equal += _ttof(caloutput);
			caloutput.Format(_T("%lf"), equal);
			check = 1;
			history.Format(_T("%lf"), equal);
			hisoutput += L'*';

		}
		else {

			if (hisoutput.Right(1) == '+')
			{
				if (check == 1) {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '*';
				}
				else {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '+';
					hisoutput += caloutput;
					equal += _ttof(caloutput);
					caloutput.Format(_T("%lf"), equal);
					check = 1;
					history.Format(_T("%lf"), equal);
					hisoutput += '*';
				}

			}
			else if (hisoutput.Right(1) == '-') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
						hisoutput += caloutput;
						equal -= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '*';
					}

				}
			}
			else if (hisoutput.Right(1) == '/') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
						hisoutput += caloutput;
						if (caloutput == '0') {
							hisoutput = "";
							caloutput = "";
						}
						equal /= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '*';
					}

				}
			}
			else if (hisoutput.Right(1) == '*' && check == 0)
			{
				hisoutput += caloutput;
				equal *= _ttof(caloutput);
				caloutput.Format(_T("%lf"), equal);
				check = 1;
				history.Format(_T("%lf"), equal);
				hisoutput += L'*';
			}
		}
		m_state = LHS_START;
		break;
	case LHS_SIGNED_DOTTED:
		if (caloutput == "0") {
			break;
		}
		if (hisoutput == "") {
			hisoutput += caloutput;
			equal += _ttof(caloutput);
			caloutput.Format(_T("%lf"), equal);
			check = 1;
			history.Format(_T("%lf"), equal);
			hisoutput += L'*';

		}
		else {

			if (hisoutput.Right(1) == '+')
			{
				if (check == 1) {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '*';
				}
				else {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '+';
					hisoutput += caloutput;
					equal += _ttof(caloutput);
					caloutput.Format(_T("%lf"), equal);
					check = 1;
					history.Format(_T("%lf"), equal);
					hisoutput += '*';
				}

			}
			else if (hisoutput.Right(1) == '-') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
						hisoutput += caloutput;
						equal -= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '*';
					}

				}
			}
			else if (hisoutput.Right(1) == '/') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
						hisoutput += caloutput;
						if (caloutput == '0') {
							hisoutput = "";
							caloutput = "";
						}
						equal /= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '*';
					}

				}
			}
			else if (hisoutput.Right(1) == '*' && check == 0)
			{
				hisoutput += caloutput;
				equal *= _ttof(caloutput);
				caloutput.Format(_T("%lf"), equal);
				check = 1;
				history.Format(_T("%lf"), equal);
				hisoutput += L'*';
			}
		}
		m_state = LHS_SIGNED_DOTTED;
		break;
	}
	UpdateData(FALSE);
}


void CDialogBasedCalculatorDlg::OnBnClickeddiv()
{
	UpdateData();
	switch (m_state) {
	case LHS_START:
		if (caloutput == "0") {
			break;
		}
		if (hisoutput == "") {
			hisoutput += caloutput;
			equal += _ttof(caloutput);
			caloutput.Format(_T("%lf"), equal);
			check = 1;
			history.Format(_T("%lf"), equal);
			hisoutput += L'/';

		}
		else {
			if (hisoutput.Right(1) == '+')
			{
				if (check == 1) {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '/';
				}
				else {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '+';
					hisoutput += caloutput;
					equal += _ttof(caloutput);
					caloutput.Format(_T("%lf"), equal);
					check = 1;
					history.Format(_T("%lf"), equal);
					hisoutput += '/';
				}

			}
			else if (hisoutput.Right(1) == '-') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
						hisoutput += caloutput;
						equal -= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '/';
					}

				}
			}
			else if (hisoutput.Right(1) == '*') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
						hisoutput += caloutput;
						equal *= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '/';
					}

				}
			}
			else if (hisoutput.Right(1) == '/' && check == 0)
			{
				hisoutput += caloutput;
				if (caloutput == '0') {
					hisoutput = "";
					caloutput = "";
					break;
				}
				equal /= _ttof(caloutput);
				caloutput.Format(_T("%lf"), equal);
				check = 1;
				history.Format(_T("%lf"), equal);
				hisoutput += L'/';
			}
	
		}

		m_state = LHS_START;
		break;
	case LHS_SIGNED:
		if (caloutput == "0") {
			break;
		}
		if (hisoutput == "") {
			hisoutput += caloutput;
			equal += _ttof(caloutput);
			caloutput.Format(_T("%lf"), equal);
			check = 1;
			history.Format(_T("%lf"), equal);
			hisoutput += L'/';

		}
		else {
			if (hisoutput.Right(1) == '+')
			{
				if (check == 1) {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '/';
				}
				else {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '+';
					hisoutput += caloutput;
					equal += _ttof(caloutput);
					caloutput.Format(_T("%lf"), equal);
					check = 1;
					history.Format(_T("%lf"), equal);
					hisoutput += '/';
				}

			}
			else if (hisoutput.Right(1) == '-') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
						hisoutput += caloutput;
						equal -= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '/';
					}

				}
			}
			else if (hisoutput.Right(1) == '*') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
						hisoutput += caloutput;
						equal *= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '/';
					}

				}
			}
			else if (hisoutput.Right(1) == '/' && check == 0)
			{
				hisoutput += caloutput;
				if (caloutput == '0') {
					hisoutput = "";
					caloutput = "";
					break;
				}
				equal /= _ttof(caloutput);
				caloutput.Format(_T("%lf"), equal);
				check = 1;
				history.Format(_T("%lf"), equal);
				hisoutput += L'/';
			}

		}
		m_state = LHS_SIGNED;
		break;
		// disallowed in the following state
	case LHS_DOTTED:
		if (caloutput == "0") {
			break;
		}
		if (hisoutput == "") {
			hisoutput += caloutput;
			equal += _ttof(caloutput);
			caloutput.Format(_T("%lf"), equal);
			check = 1;
			history.Format(_T("%lf"), equal);
			hisoutput += L'/';

		}
		else {
			if (hisoutput.Right(1) == '+')
			{
				if (check == 1) {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '/';
				}
				else {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '+';
					hisoutput += caloutput;
					equal += _ttof(caloutput);
					caloutput.Format(_T("%lf"), equal);
					check = 1;
					history.Format(_T("%lf"), equal);
					hisoutput += '/';
				}

			}
			else if (hisoutput.Right(1) == '-') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
						hisoutput += caloutput;
						equal -= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '/';
					}

				}
			}
			else if (hisoutput.Right(1) == '*') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
						hisoutput += caloutput;
						equal *= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '/';
					}

				}
			}
			else if (hisoutput.Right(1) == '/' && check == 0)
			{
				hisoutput += caloutput;
				if (caloutput == '0') {
					hisoutput = "";
					caloutput = "";
					break;
				}
				equal /= _ttof(caloutput);
				caloutput.Format(_T("%lf"), equal);
				check = 1;
				history.Format(_T("%lf"), equal);
				hisoutput += L'/';
			}

		}
		m_state = LHS_DOTTED;
		break;
	case LHS_SIGNED_DOTTED:
		if (caloutput == "0") {
			break;
		}
		if (hisoutput == "") {
			hisoutput += caloutput;
			equal += _ttof(caloutput);
			caloutput.Format(_T("%lf"), equal);
			check = 1;
			history.Format(_T("%lf"), equal);
			hisoutput += L'/';

		}
		else {
			if (hisoutput.Right(1) == '+')
			{
				if (check == 1) {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '/';
				}
				else {
					hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
					hisoutput += '+';
					hisoutput += caloutput;
					equal += _ttof(caloutput);
					caloutput.Format(_T("%lf"), equal);
					check = 1;
					history.Format(_T("%lf"), equal);
					hisoutput += '/';
				}

			}
			else if (hisoutput.Right(1) == '-') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '-';
						hisoutput += caloutput;
						equal -= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '/';
					}

				}
			}
			else if (hisoutput.Right(1) == '*') {
				{
					if (check == 1) {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '/';
					}
					else {
						hisoutput = hisoutput.Left(hisoutput.GetLength() - 1);
						hisoutput += '*';
						hisoutput += caloutput;
						equal *= _ttof(caloutput);
						caloutput.Format(_T("%lf"), equal);
						check = 1;
						history.Format(_T("%lf"), equal);
						hisoutput += '/';
					}

				}
			}
			else if (hisoutput.Right(1) == '/' && check == 0)
			{
				hisoutput += caloutput;
				if (caloutput == '0') {
					hisoutput = "";
					caloutput = "";
					break;
				}
				equal /= _ttof(caloutput);
				caloutput.Format(_T("%lf"), equal);
				check = 1;
				history.Format(_T("%lf"), equal);
				hisoutput += L'/';
			}

		}
		m_state = LHS_SIGNED_DOTTED;
		break;
	}

	UpdateData(FALSE);
}
