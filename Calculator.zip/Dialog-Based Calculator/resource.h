﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 DialogBasedCalculator.rc 使用
//
#define IDD_DIALOGBASED_CALCULATOR_DIALOG 102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON_2ND                  1001
#define IDC_powx2                       1002
#define IDC_POWX12                      1003
#define IDC_CAL                         1004
#define IDC_CALEDIT                     1004
#define IDC_HISTORY                     1005
#define IDC_History1                    1006
#define IDC_HISTORY2                    1007
#define IDC_PI                          1034
#define IDC_1DIVX                       1035
#define IDC_Leftpa                      1036
#define IDC_e                           1037
#define IDC_ABSX                        1038
#define IDC_Rightpa                     1039
#define IDC_C                           1040
#define IDC_EXP                         1041
#define IDC_fact                        1042
#define IDC_BACKSPACE                   1043
#define IDC_MOD                         1044
#define IDC_div                         1045
#define IDC_powxy                       1046
#define IDC_pow10x                      1047
#define IDC_log                         1048
#define IDC_BUTTON7                     1049
#define IDC_BUTTON4                     1050
#define IDC_BUTTON1                     1051
#define IDC_BUTTON8                     1052
#define IDC_BUTTON5                     1053
#define IDC_BUTTON2                     1054
#define IDC_BUTTON9                     1055
#define IDC_BUTTON6                     1056
#define IDC_BUTTON3                     1057
#define IDC_X                           1058
#define IDC_MINUS                       1059
#define IDC_PLUS                        1060
#define IDC_in                          1061
#define IDC_NEG                         1062
#define IDC_BUTTON0                     1063
#define IDC_DOT                         1064
#define IDC_EQUAL                       1065

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
