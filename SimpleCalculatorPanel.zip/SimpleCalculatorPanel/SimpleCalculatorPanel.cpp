﻿// SimpleCalculatorPanel.cpp : 定義應用程式的進入點。
//

#include "framework.h"
#include "SimpleCalculatorPanel.h"

#define MAX_LOADSTRING 100
#define IDC_EDITBOX_TEXT 1000
#define IDC_PUSHBUTTON_BUTTON1 1001
#define IDC_PUSHBUTTON_BUTTON2 1002
#define IDC_PUSHBUTTON_BUTTON3 1003
#define IDC_PUSHBUTTON_BUTTON4 1004
#define IDC_PUSHBUTTON_BUTTON5 1005
#define IDC_PUSHBUTTON_BUTTON6 1006
#define IDC_PUSHBUTTON_BUTTON7 1007
#define IDC_PUSHBUTTON_BUTTON8 1008
#define IDC_PUSHBUTTON_BUTTON9 1009
#define IDC_PUSHBUTTON_BUTTON0 10010
#define IDC_PUSHBUTTON_BUTTON00 1011
#define IDC_PUSHBUTTON_BUTTON000 1012
#define IDC_PUSHBUTTON_BUTTONC 1013
#define IDC_PUSHBUTTON_BUTTONBACKSPACE 1014
#define IDC_PUSHBUTTON_BUTTONPLUS 1015
#define IDC_PUSHBUTTON_BUTTONENTER 1016



// 全域變數:
HINSTANCE hInst;                                // 目前執行個體
WCHAR szTitle[MAX_LOADSTRING];                  // 標題列文字
WCHAR szWindowClass[MAX_LOADSTRING];            // 主視窗類別名稱

// 這個程式碼模組所包含之函式的向前宣告:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
    _In_opt_ HINSTANCE hPrevInstance,
    _In_ LPWSTR    lpCmdLine,
    _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: 在此放置程式碼。

    // 將全域字串初始化
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_SIMPLECALCULATORPANEL, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // 執行應用程式初始化:
    if (!InitInstance(hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_SIMPLECALCULATORPANEL));

    MSG msg;

    // 主訊息迴圈:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int)msg.wParam;
}



//
//  函式: MyRegisterClass()
//
//  用途: 註冊視窗類別。
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_SIMPLECALCULATORPANEL));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszMenuName = MAKEINTRESOURCEW(IDC_SIMPLECALCULATORPANEL);
    wcex.lpszClassName = szWindowClass;
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

//
//   函式: InitInstance(HINSTANCE, int)
//
//   用途: 儲存執行個體控制代碼並且建立主視窗
//
//   註解:
//
//        在這個函式中，我們將執行個體控制代碼儲存在全域變數中，
//        並建立及顯示主程式視窗。
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    hInst = hInstance; // 將執行個體控制代碼儲存在全域變數中

    HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

    if (!hWnd)
    {
        return FALSE;
    }

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    return TRUE;
}

//
//  函式: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  用途: 處理主視窗的訊息。
//
//  WM_COMMAND  - 處理應用程式功能表
//  WM_PAINT    - 繪製主視窗
//  WM_DESTROY  - 張貼結束訊息然後傳回
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    static HWND hWndStatic = 0;
    static HWND hWndButton1 = 0;
    static HWND hWndButton2 = 0;
    static HWND hWndButton3 = 0;
    static HWND hWndButton4 = 0;
    static HWND hWndButton5 = 0;
    static HWND hWndButton6 = 0;
    static HWND hWndButton7 = 0;
    static HWND hWndButton8 = 0;
    static HWND hWndButton9 = 0;
    static HWND hWndButton0 = 0;
    static HWND hWndButton00 = 0;
    static HWND hWndButton000 = 0;
    static HWND hWndButtonplus = 0;
    static HWND hWndButtonbackspace = 0;
    static HWND hWndButtonenter = 0;
    static HWND hWndButtonC = 0;
    WCHAR Buffer[32] = {' '};
    switch (message)
    {
    case WM_COMMAND:
    {
        int wmId = LOWORD(wParam);
        // 剖析功能表選取項目:
        switch (wmId)
        {
        case IDC_PUSHBUTTON_BUTTON1 :
        case IDC_PUSHBUTTON_BUTTON2: 
        case IDC_PUSHBUTTON_BUTTON3 :
        case IDC_PUSHBUTTON_BUTTON4 :
        case IDC_PUSHBUTTON_BUTTON5 :
        case IDC_PUSHBUTTON_BUTTON6 :
        case IDC_PUSHBUTTON_BUTTON7 :
        case IDC_PUSHBUTTON_BUTTON8 :
        case IDC_PUSHBUTTON_BUTTON9 :
        case IDC_PUSHBUTTON_BUTTON0 :
        case IDC_PUSHBUTTON_BUTTON00 :
        case IDC_PUSHBUTTON_BUTTON000 :
        case IDC_PUSHBUTTON_BUTTONC :
        case IDC_PUSHBUTTON_BUTTONBACKSPACE :
        case IDC_PUSHBUTTON_BUTTONPLUS :
        case IDC_PUSHBUTTON_BUTTONENTER :
        {
            
            switch (HIWORD(wParam))
            {

                case BN_CLICKED:
                {

                    GetWindowText(hWndStatic, Buffer, 32);
                  
                    HWND hWndTarget=NULL;
                    for(int i=1001;i<=1009;i++){
                        if (wcslen(Buffer) >= 31) {
                            break;
                        }
                        if (wmId == i) {
                            hWndTarget = hWndStatic;
                            if (Buffer[wcslen(Buffer) - 1] == '0'&& wcslen(Buffer)==1)
                                Buffer[wcslen(Buffer) - 1] = (i - 1000)+'0';
                            else
                                Buffer[wcslen(Buffer)] = (i - 1000) + '0';
                        }
                    }
                    if (wmId == 10010) {
                        hWndTarget = hWndStatic;
                        if (wcslen(Buffer) >= 31) {
                            break;
                        }
                        if (Buffer[wcslen(Buffer) - 1] == '0' && wcslen(Buffer) == 1);
                            
                        else
                            Buffer[wcslen(Buffer)] = '0';
                    }
                    if (wmId == 1011) {
                        if (wcslen(Buffer) >= 31|| wcslen(Buffer) >= 30) {
                            break;
                        }
                        hWndTarget = hWndStatic;
                        if (Buffer[wcslen(Buffer) - 1] == '0' && wcslen(Buffer) == 1);
                            
                        else {
                            Buffer[wcslen(Buffer)] = '0'; Buffer[wcslen(Buffer)] = '0';
                        }
                    }
                    if (wmId == 1012) {
                        if (wcslen(Buffer) >= 31 || wcslen(Buffer) >= 30|| wcslen(Buffer) >= 29) {
                            break;
                        }
                        hWndTarget = hWndStatic;
                        if (Buffer[wcslen(Buffer) - 1] == '0' && wcslen(Buffer) == 1);

                        else {
                            Buffer[wcslen(Buffer)] = '0'; Buffer[wcslen(Buffer)] = '0'; Buffer[wcslen(Buffer)] = '0';
                        }

                    }
                    if (wmId == 1013) {
                        hWndTarget = hWndStatic;
                        for (int i = wcslen(Buffer); i >0; i--) {
                            if (wcslen(Buffer) == 1) {
                                Buffer[0] = '0';
                                break;
                            }
                            Buffer[i-1] = Buffer[i];
                        }
                    }
                   
                    if (wmId == 1014) {
                        hWndTarget = hWndStatic;
                            if (wcslen(Buffer) == 1) {
                                Buffer[0] = '0';
                               
                            }
                            else {
                              
                                Buffer[wcslen(Buffer) - 1] = Buffer[wcslen(Buffer)];
                              
                            }
                        
                    }
                   
                    
            
                    SetWindowText(hWndTarget, Buffer);
                }
                

            }
            break;
        }
        break;

        case IDM_ABOUT:
            DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
            break;
        case IDM_EXIT:
            DestroyWindow(hWnd);
            break;
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
        }
    }
    break;
    case WM_CREATE:
    {
        hWndStatic = CreateWindow(
            TEXT("STATIC"),
            TEXT("0"),
            WS_VISIBLE | WS_CHILD | WS_BORDER|SS_RIGHT,
            5, 5, 275, 25,
            hWnd, 0, hInst, NULL);
        hWndButton1 = CreateWindow(
            L"BUTTON",
            L"1",
            WS_VISIBLE | WS_CHILD,
            5, 35, 65, 65, hWnd,
            (HMENU)IDC_PUSHBUTTON_BUTTON1,  hInst, NULL);
        hWndButton2 = CreateWindow(
            L"BUTTON",
            L"2",
            WS_VISIBLE | WS_CHILD,
            75, 35, 65, 65, hWnd,
            (HMENU)IDC_PUSHBUTTON_BUTTON2, hInst, NULL);
        hWndButton3 = CreateWindow(
            L"BUTTON",
            L"3",
            WS_VISIBLE | WS_CHILD,
            145, 35, 65, 65, hWnd,
            (HMENU)IDC_PUSHBUTTON_BUTTON3,  hInst, NULL);
        hWndButtonC = CreateWindow(
            L"BUTTON",
            L"C",
            WS_VISIBLE | WS_CHILD,
            215, 35, 65, 65, hWnd,
            (HMENU)IDC_PUSHBUTTON_BUTTONC,  hInst, NULL);
        hWndButton4 = CreateWindow(
            L"BUTTON",
            L"4",
            WS_VISIBLE | WS_CHILD,
            5, 105, 65, 65, hWnd,
            (HMENU)IDC_PUSHBUTTON_BUTTON4,  hInst, NULL);
        hWndButton5 = CreateWindow(
            L"BUTTON",
            L"5",
            WS_VISIBLE | WS_CHILD,
            75, 105, 65, 65, hWnd,
            (HMENU)IDC_PUSHBUTTON_BUTTON5,  hInst, NULL);
        hWndButton6 = CreateWindow(
            L"BUTTON",
            L"6",
            WS_VISIBLE | WS_CHILD,
            145, 105, 65, 65, hWnd,
            (HMENU)IDC_PUSHBUTTON_BUTTON6,  hInst, NULL);
        hWndButtonbackspace = CreateWindow(
            L"BUTTON",
            L"<-",
            WS_VISIBLE | WS_CHILD,
            215, 105, 65, 65, hWnd,
            (HMENU)IDC_PUSHBUTTON_BUTTONBACKSPACE, hInst, NULL);
        hWndButton7 = CreateWindow(
            L"BUTTON",
            L"7",
            WS_VISIBLE | WS_CHILD,
            5, 175, 65, 65, hWnd,
            (HMENU)IDC_PUSHBUTTON_BUTTON7,  hInst, NULL);
        hWndButton8 = CreateWindow(
            L"BUTTON",
            L"8",
            WS_VISIBLE | WS_CHILD,
            75, 175, 65, 65, hWnd,
            (HMENU)IDC_PUSHBUTTON_BUTTON8,  hInst, NULL);
        hWndButton9 = CreateWindow(
            L"BUTTON",
            L"9",
            WS_VISIBLE | WS_CHILD,
            145, 175, 65, 65, hWnd,
            (HMENU)IDC_PUSHBUTTON_BUTTON9,  hInst, NULL);
        hWndButtonplus = CreateWindow(
            L"BUTTON",
            L"+",
            WS_VISIBLE | WS_CHILD,
            215, 175, 65, 65, hWnd,
            (HMENU)IDC_PUSHBUTTON_BUTTONPLUS,  hInst, NULL);
        hWndButton0 = CreateWindow(
            L"BUTTON",
            L"0",
            WS_VISIBLE | WS_CHILD,
            5, 245, 65, 65, hWnd,
            (HMENU)IDC_PUSHBUTTON_BUTTON0,  hInst, NULL);
        hWndButton00 = CreateWindow(
            L"BUTTON",
            L"00",
            WS_VISIBLE | WS_CHILD,
            75, 245, 65, 65, hWnd,
            (HMENU)IDC_PUSHBUTTON_BUTTON00, hInst, NULL);
        hWndButton000 = CreateWindow(
            L"BUTTON",
            L"000",
            WS_VISIBLE | WS_CHILD,
            145, 245, 65, 65, hWnd,
            (HMENU)IDC_PUSHBUTTON_BUTTON000,  hInst, NULL);
        hWndButtonenter = CreateWindow(
            L"BUTTON",
            L"ENTER",
            WS_VISIBLE | WS_CHILD,
            215, 245, 65, 65, hWnd,
            (HMENU)IDC_PUSHBUTTON_BUTTONENTER,  hInst, NULL);
    }
    break;
    case WM_CTLCOLORSTATIC:
    {
        HDC hdcStatic = (HDC)wParam;
        SetTextColor(hdcStatic, RGB(0, 0, 0));
        SetBkColor(hdcStatic, RGB(255, 255, 255));
        return (INT_PTR)CreateSolidBrush(RGB(255, 255, 255));
    }
    break;
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        // TODO: 在此新增任何使用 hdc 的繪圖程式碼...
        EndPaint(hWnd, &ps);
    }
    break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

// [關於] 方塊的訊息處理常式。
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}
