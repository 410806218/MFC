﻿
// UI3B18_ PainterrOwnerDrawView.h: CUI3B18PainterrOwnerDrawView 類別的介面
//

#pragma once
#include "CShape.h"

enum SHAPE { NONE, CG, LINE, RECTANGLE, ELLIPSE, POLYGON, SCRIBBLE };


class CUI3B18PainterrOwnerDrawView : public CView
{
protected: // 僅從序列化建立
	CUI3B18PainterrOwnerDrawView() noexcept;
	DECLARE_DYNCREATE(CUI3B18PainterrOwnerDrawView)

// 屬性
public:
	CUI3B18PainterrOwnerDrawDoc* GetDocument() const;
	CShape* CreateShape(SHAPE shape);
	afx_msg void SaveShape();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void ChangeShape(UINT nID);
	afx_msg void ChangeColor(UINT nID);
	afx_msg void ChangeSIZE(UINT nID);
	afx_msg void ChangeFillColor(UINT nID);
	SHAPE m_nShapeDrawing;	// 繪製中圖形
	CShape* m_pShape;	// 繪製中圖形指標
	int m_nLineWidth;
	

	COLORREF m_colorLine;
	BOOL  m_bFill;
	COLORREF m_colorFill;
// 作業
public:

// 覆寫
public:
	virtual void OnDraw(CDC* pDC);  // 覆寫以描繪此檢視
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

// 程式碼實作
public:
	virtual ~CUI3B18PainterrOwnerDrawView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 產生的訊息對應函式
protected:
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // 對 UI3B18_ PainterrOwnerDrawView.cpp 中的版本進行偵錯
inline CUI3B18PainterrOwnerDrawDoc* CUI3B18PainterrOwnerDrawView::GetDocument() const
   { return reinterpret_cast<CUI3B18PainterrOwnerDrawDoc*>(m_pDocument); }
#endif

