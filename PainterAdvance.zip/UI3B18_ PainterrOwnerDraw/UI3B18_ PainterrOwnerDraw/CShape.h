﻿#pragma once
#include "CShape.h"

// CShape 命令目標
interface ShapeEdit
{
    virtual BOOL StartEdit(CWnd* pWnd, UINT nFlags, CPoint point) { return FALSE; }
    virtual BOOL OnLButtonDown(CWnd* pWnd, UINT nFlags, CPoint point) { return FALSE; }
    virtual BOOL OnMouseMove(CWnd* pWnd, UINT nFlags, CPoint point) { return FALSE; }
    virtual BOOL OnLButtonUp(CWnd* pWnd, UINT nFlags, CPoint point) { return FALSE; }
    virtual BOOL OnLButtonDblClk(CWnd* pWnd, UINT nFlags, CPoint point) { return FALSE; }
    virtual BOOL OnEscape(CWnd* pWnd) { return FALSE; }
};

class CShape : public CObject,public ShapeEdit
{


public:
    CShape(int w = 1, BOOL f = TRUE, COLORREF cl = RGB(0, 0, 0), COLORREF cf = RGB(255, 255, 255)); // 建構子

    virtual ~CShape();
public:
    int m_nLineWidth;				// 線(外框)寬
    COLORREF m_colorLine;				// 線(外框)顏色
    BOOL m_bFill;					// 是否填充
    COLORREF m_colorFill;				// 填充色
    CArray<POINT> m_pts;				// 構成點

    // 作業函數
public:
    void Draw(CDC* pDC);				// 繪製圖形

    // 覆寫函數
public:
    virtual void Serialize(CArchive& ar);		// 序列化
    virtual BOOL IsValid(BOOL attrOnly = FALSE);	// 判斷圖形是否有效
    virtual void Sketch(CDC* pDC) = 0;		// 繪製輪廓(抽象函數)
    virtual BOOL StartEdit(CWnd* pWnd, UINT nFlags, CPoint point);
    virtual BOOL OnMouseMove(CWnd* pWnd, UINT nFlags, CPoint point);
    virtual BOOL OnEscape(CWnd* pWnd);



};

class CFullyConnectedGraph :
    public CShape
{
public:
    CFullyConnectedGraph();		// 執行期類別必須含一無參數建構子
    CFullyConnectedGraph(int w, COLORREF cl);	// 參數：線寬，顏色

    DECLARE_SERIAL(CFullyConnectedGraph)	// 可序列化執行其類別

    // 覆寫
public:
    virtual void Sketch(CDC* pDC);	// 繪製輪廓
   
   // virtual BOOL StartEdit(CWnd* pWnd, UINT nFlags, CPoint point);

    //virtual BOOL OnLButtonDown(CWnd* pWnd, UINT nFlags, CPoint point);
    virtual BOOL OnMouseMove(CWnd* pWnd, UINT nFlags, CPoint point);
  
};

class CLine :
    public CShape
{
public:
    CLine();		// 執行期類別必須含一無參數建構子
  //  virtual BOOL StartEdit(CWnd* pWnd, UINT nFlags, CPoint point);
    CLine(int w, COLORREF cl);	// 參數：線寬，顏色

    DECLARE_SERIAL(CLine)	// 可序列化執行其類別

    // 覆寫
public:
    virtual void Sketch(CDC* pDC);	// 繪製輪廓

};

class CRectangle :
    public CShape
{
public:
    CRectangle();		// 執行期類別必須含一無參數建構子
    CRectangle(int w, COLORREF cl, BOOL f, COLORREF cf);// 完整參數

    DECLARE_SERIAL(CRectangle)		// 可序列化執行其類別

    // 覆寫
public:
    virtual void Sketch(CDC* pDC);	// 繪製輪廓
    virtual BOOL OnMouseMove(CWnd* pWnd, UINT nFlags, CPoint point);


};

class CEllipse :
    public CShape
{
public:
    CEllipse();		// 執行期類別必須含一無參數建構子
    CEllipse(int w, COLORREF cl, BOOL f, COLORREF cf);// 完整參數
    DECLARE_SERIAL(CEllipse)		// 可序列化執行其類別
public:
    virtual void Sketch(CDC* pDC);	// 繪製輪廓
    virtual BOOL OnMouseMove(CWnd* pWnd, UINT nFlags, CPoint point);
};

class CPolygon :
    public CShape
{
public:
    CPolygon();			// 執行期類別必須含一無參數建構子
    CPolygon(int w, COLORREF cl, BOOL f, COLORREF cf);	// 完整參數

    DECLARE_SERIAL(CPolygon) 	// 可序列化執行其類別

    // 覆寫
public:
    virtual void Sketch(CDC* pDC);	// 繪製輪廓
   // virtual BOOL OnLButtonDown(CWnd* pWnd, UINT nFlags, CPoint point);
    virtual BOOL OnMouseMove(CWnd* pWnd, UINT nFlags, CPoint point);
    //virtual BOOL OnLButtonUp(CWnd* pWnd, UINT nFlags, CPoint point);
    //virtual BOOL OnLButtonDblClk(CWnd* pWnd, UINT nFlags, CPoint point);

};

class CScribble :
    public CShape
{
public:
    CScribble();		// 執行期類別必須含一無參數建構子
    CScribble(int w, COLORREF cl);	// 參數：線寬，顏色

    DECLARE_SERIAL(CScribble)		// 可序列化執行其類別

    // 覆寫
public:
    virtual void Sketch(CDC* pDC);
  
   // virtual BOOL StartEdit(CWnd* pWnd, UINT nFlags, CPoint point);
    virtual BOOL OnMouseMove(CWnd* pWnd, UINT nFlags, CPoint point);

};

