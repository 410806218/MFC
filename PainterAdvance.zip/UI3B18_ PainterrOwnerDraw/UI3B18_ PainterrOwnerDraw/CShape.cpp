﻿// CShape.cpp: 實作檔案
//

#include "pch.h"
#include "UI3B18_ PainterrOwnerDraw.h"
#include "CShape.h"


// CShape

CShape::CShape(int w, BOOL f, COLORREF cl, COLORREF cf)
	: m_nLineWidth(w)
	, m_colorLine(cl)
	, m_bFill(f)
	, m_colorFill(cf)
{

}


CShape::~CShape()
{
}
BOOL CShape::IsValid(BOOL attrOnly)
{
	if (attrOnly) return m_nLineWidth > 0 || m_bFill;
	return (m_nLineWidth > 0 || m_bFill) && m_pts.GetSize() >= 2;
}
void CShape::Draw(CDC* pDC)
{
	// DC選取工具
	CPen pen(PS_SOLID, max(1, m_nLineWidth), m_colorLine);
	CGdiObject* pOldPen;
	if (m_nLineWidth) pOldPen = pDC->SelectObject(&pen);
	else pOldPen = pDC->SelectStockObject(NULL_PEN);

	CBrush brush(m_colorFill);
	CGdiObject* pOldBrush;
	if (m_bFill) pOldBrush = pDC->SelectObject(&brush);
	else pOldBrush = pDC->SelectStockObject(NULL_BRUSH);

	Sketch(pDC);	 		// 呼叫衍生類別之Sketch

	// 還原DC
	pDC->SelectObject(pOldPen);
	pDC->SelectObject(pOldBrush);
}

void CShape::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: 在此加入儲存程式碼
		ar << m_nLineWidth << m_bFill;
		ar << m_colorLine << m_colorFill;
	}
	else
	{
		// TODO: 在此加入載入程式碼
		ar >> m_nLineWidth >> m_bFill;
		ar >> m_colorLine >> m_colorFill;
	}
	m_pts.Serialize(ar);
}
BOOL CShape::StartEdit(CWnd* pWnd, UINT nFlags, CPoint point)
{
	if (!IsValid(TRUE))	// 判斷圖形屬性是否可視
		return FALSE;	// 不可視則返回偽，表示繪圖不可繼續

	m_pts.RemoveAll();	// 移除動態陣列所有點（實可免此呼叫）
	pWnd->SetCapture();	// 鎖定滑鼠
	m_pts.Add(point);	// 加入錨點
	m_pts.Add(point);	// 加入未定之次一點

	// 因已鎖定滑鼠故設定游標
	(AfxGetApp()->LoadCursor(MAKEINTRESOURCE(IDC_CURSOR_LBTNDOWN)));
	return TRUE;		// 返回真，表示繪圖未完成，須繼續進行
}
BOOL CShape::OnMouseMove(CWnd* pWnd, UINT nFlags, CPoint point)
{
	CClientDC dc(pWnd);	// 建構視窗DC
	CGdiObject* pOldPen = dc.SelectStockObject(WHITE_PEN);	// 白筆
	CGdiObject* pOldBrush = dc.SelectStockObject(NULL_BRUSH);	// 空刷

	dc.SetROP2(R2_XORPEN);		// XOR繪圖模式

	Sketch(&dc);			// 擦去舊輪廓

	m_pts[1] = point;		// 改變第二點
	Sketch(&dc);			// 繪製新輪廓

	dc.SelectObject(pOldPen);
	dc.SelectObject(pOldBrush);

	return TRUE;		// 傳回真，表示繪圖尚未完成，繪圖應持續進行
}
BOOL CShape::OnEscape(CWnd* pWnd)
{
	m_pts.RemoveAll();	// 清空已置入動態陣列中所有點
	return FALSE;	// 傳回偽，表示繪圖已完成，繪圖不再持續
}
//======================================================
// CLine

IMPLEMENT_SERIAL(CLine, CShape, 1)

CLine::CLine(int w, COLORREF cl)
	: CShape(w, cl)
{
	m_nLineWidth = w;
	m_colorLine = cl;
}

CLine::CLine()
{
}
/*BOOL CLine::StartEdit(CWnd* pWnd, UINT nFlags, CPoint point)
{
	m_pts.RemoveAll();
	pWnd->SetCapture();	// 鎖定滑鼠
	m_pts.Add(point);	// 加入錨點，無未確定點

	SetCursor(AfxGetApp()->LoadCursor(MAKEINTRESOURCE(IDC_CURSOR_LBTNDOWN)));
	return TRUE;
}*/
void CLine::Sketch(CDC* pDC)
{
	pDC->MoveTo(m_pts[0]);
	pDC->LineTo(m_pts[1]);
}
//======================================================
// CScribble

IMPLEMENT_SERIAL(CScribble, CShape, 1)

CScribble::CScribble(int w, COLORREF cl)
	: CShape(w, cl)
{
	m_nLineWidth = w;
	m_colorLine = cl;
}

CScribble::CScribble()
{
}

void CScribble::Sketch(CDC* pDC)
{
	int sz = m_pts.GetSize();
	pDC->MoveTo(m_pts[0]);
	for (int i = 1; i < sz; i++)
		pDC->LineTo(m_pts[i]);

}



BOOL CScribble::OnMouseMove(CWnd* pWnd, UINT nFlags, CPoint point)
{
	CClientDC dc(pWnd);
	m_pts.Add(point);
	Draw(&dc);
	return TRUE;
}

//======================================================
// CFullyConnectGraph

IMPLEMENT_SERIAL(CFullyConnectedGraph, CShape, 1)

CFullyConnectedGraph::CFullyConnectedGraph(int w, COLORREF cl)
	: CShape(w, cl)
{
	m_nLineWidth = w;
	m_colorLine = cl;
}

CFullyConnectedGraph::CFullyConnectedGraph()
{

}

void CFullyConnectedGraph::Sketch(CDC* pDC)
{
	CPen pen(PS_SOLID, m_nLineWidth, m_colorLine);
	pDC->SelectObject(GetStockObject(NULL_BRUSH));
	if (m_colorFill != NULL) {
		pDC->SelectObject(GetStockObject(DC_BRUSH));
		pDC->SetDCBrushColor(m_colorFill);
	}
	CGdiObject* pOldPen = pDC->SelectObject(&pen);

	int sz = m_pts.GetSize();
	for (int i = 0; i < sz; i++)

		for (int j = i + 1; j < sz; j++)
		{
			pDC->MoveTo(m_pts[i]);
			pDC->LineTo(m_pts[j]);
		}


	pDC->SelectObject(pOldPen);
}


BOOL CFullyConnectedGraph::OnMouseMove(CWnd* pWnd, UINT nFlags, CPoint point)
{
	CClientDC dc(pWnd);
	m_pts.Add(point);
	CGdiObject* pOldPen = dc.SelectStockObject(WHITE_PEN);
	dc.SetROP2(R2_XORPEN);			// XOR pen
	

	int sz = m_pts.GetSize();
	POINT ptFloat = m_pts[sz - 1];		// 未定之點
	POINT ptFixed = m_pts[sz - 2];			// 已定之點
	if (ptFloat.x != ptFixed.x || ptFloat.y != ptFixed.y) // 未定之點 != 已定之點
		for (int i = 0; i < sz - 1; i++) {
			dc.MoveTo(ptFloat);
			dc.LineTo(m_pts[i]);
		}
	// 繪製新線	
	m_pts[sz - 1] = point;// 改變未定點
	for (int i = 0; i < sz - 1; i++) {
		dc.MoveTo(point);
		dc.LineTo(m_pts[i]);
	}
	dc.SelectObject(pOldPen);
	return TRUE;
}
// ======================================================
// CRectangle

IMPLEMENT_SERIAL(CRectangle, CShape, 1)

CRectangle::CRectangle()
{
}

CRectangle::CRectangle(int w, COLORREF cl, BOOL f, COLORREF cf)
	: CShape(w, cl, f, cf)
{
	m_nLineWidth = w;
	m_colorLine = cl;
	m_bFill = f;
	m_colorFill = cf;
}

void CRectangle::Sketch(CDC* pDC)
{
	CPen pen(PS_SOLID, m_nLineWidth, m_colorLine);
	pDC->SelectObject(GetStockObject(NULL_BRUSH));
	if (m_colorFill != NULL) {
		pDC->SelectObject(GetStockObject(DC_BRUSH));
		pDC->SetDCBrushColor(RGB(255, 255, 255) - m_colorFill);
	}
	CGdiObject* pOldPen = pDC->SelectObject(&pen);
	CRect rect(m_pts[0].x, m_pts[0].y, m_pts[1].x, m_pts[1].y);
	pDC->Rectangle(&rect);
}
BOOL CRectangle::OnMouseMove(CWnd* pWnd, UINT nFlags, CPoint point)
{

	CClientDC dc(pWnd);
	CGdiObject* pOldPen = dc.SelectStockObject(WHITE_PEN);
	dc.SetROP2(R2_XORPEN);        // XOR pen

	dc.SelectObject(GetStockObject(DC_BRUSH));
	dc.SelectObject(GetStockObject(DC_PEN));

	dc.SetDCPenColor(RGB(255, 255, 255) - m_colorLine);

	dc.SetDCBrushColor(m_colorFill);
	int sz = m_pts.GetSize();
	POINT ptFloat = m_pts[sz - 1];    // 未定之點
	POINT ptFixed = m_pts[sz - 2];    // 已定之點

	if (ptFloat.x != ptFixed.x || ptFloat.y != ptFixed.y) // 未定之點 != 已定之點
	{
		dc.Rectangle(ptFloat.x, ptFloat.y, ptFixed.x, ptFixed.y);
	}
	// 繪製新線
	// 繪製新線
	m_pts[sz - 1] = point;// 改變未定點
	ptFloat = m_pts[sz - 1];    // 未定之點
	ptFixed = m_pts[sz - 2];    // 已定之點

	dc.Rectangle(ptFloat.x, ptFloat.y, ptFixed.x, ptFixed.y);

	dc.SelectObject(pOldPen);

	return TRUE;
}


// ======================================================
// CEllipse

IMPLEMENT_SERIAL(CEllipse, CShape, 1)

CEllipse::CEllipse()
{
}

CEllipse::CEllipse(int w, COLORREF cl, BOOL f, COLORREF cf)
	: CShape(w, cl, f, cf)
{
	m_nLineWidth = w;
	m_colorLine = cl;
	m_bFill = f;
	m_colorFill = cf;
}

void CEllipse::Sketch(CDC* pDC)
{
	CPen pen(PS_SOLID, m_nLineWidth, m_colorLine);
	pDC->SelectObject(GetStockObject(NULL_BRUSH));
	if (m_colorFill != NULL) {
		pDC->SelectObject(GetStockObject(DC_BRUSH));
		pDC->SetDCBrushColor(RGB(255, 255, 255) - m_colorFill);
	}
	CGdiObject* pOldPen = pDC->SelectObject(&pen);
	CRect Ellipse(m_pts[0].x, m_pts[0].y, m_pts[1].x, m_pts[1].y);
	pDC->Ellipse(&Ellipse);
}
BOOL CEllipse::OnMouseMove(CWnd* pWnd, UINT nFlags, CPoint point)
{

	CClientDC dc(pWnd);
	CGdiObject* pOldPen = dc.SelectStockObject(WHITE_PEN);
	dc.SetROP2(R2_XORPEN);        // XOR pen

	dc.SelectObject(GetStockObject(DC_BRUSH));
	dc.SelectObject(GetStockObject(DC_PEN));

	dc.SetDCPenColor(RGB(255, 255, 255) - m_colorLine);

	dc.SetDCBrushColor(m_colorFill);
	int sz = m_pts.GetSize();
	POINT ptFloat = m_pts[sz - 1];    // 未定之點
	POINT ptFixed = m_pts[sz - 2];    // 已定之點

	if (ptFloat.x != ptFixed.x || ptFloat.y != ptFixed.y) // 未定之點 != 已定之點
	{
		dc.Ellipse(ptFloat.x, ptFloat.y, ptFixed.x, ptFixed.y);
	}
	// 繪製新線
	// 繪製新線
	m_pts[sz - 1] = point;// 改變未定點
	ptFloat = m_pts[sz - 1];    // 未定之點
	ptFixed = m_pts[sz - 2];    // 已定之點

	dc.Ellipse(ptFloat.x, ptFloat.y, ptFixed.x, ptFixed.y);

	dc.SelectObject(pOldPen);

	return TRUE;
}
// ======================================================
// CPolygon

IMPLEMENT_SERIAL(CPolygon, CShape, 1)

CPolygon::CPolygon()
{
}

CPolygon::CPolygon(int w, COLORREF cl, BOOL f, COLORREF cf)
	: CShape(w, cl, f, cf)
{
	m_nLineWidth = w;
	m_colorLine = cl;
	m_bFill = f;
	m_colorFill = cf;
}

void CPolygon::Sketch(CDC* pDC)
{
	CPen pen(PS_SOLID, m_nLineWidth, m_colorLine);
	pDC->SelectObject(GetStockObject(NULL_BRUSH));
	if (m_colorFill != NULL) {
		pDC->SelectObject(GetStockObject(DC_BRUSH));
		pDC->SetDCBrushColor(RGB(255, 255, 255) - m_colorFill);
	}
	CGdiObject* pOldPen = pDC->SelectObject(&pen);
	//POINT* p = m_pts.GetData();	// 從動態陣列中取得資料起點
	POINT p[5];
	int  r = (int)sqrt(pow((double)(m_pts[1].x - m_pts[0].x), 2) + pow((double)(m_pts[1].y - m_pts[0].y), 2));
	p[0].x = m_pts[0].x;
	p[0].y = m_pts[0].y - r;
	p[1].x = (LONG)(m_pts[0].x - r * sin(72 * 3.14 / 180));/*極座標*/
	p[1].y = (LONG)(m_pts[0].y - r * cos(72 * 3.14 / 180));
	p[2].x = (LONG)(m_pts[0].x - r * sin(36 * 3.14 / 180));
	p[2].y = (LONG)(m_pts[0].y + r * cos(36 * 3.14 / 180));
	p[3].x = (LONG)(m_pts[0].x + r * sin(36 * 3.14 / 180));
	p[3].y = (LONG)(m_pts[0].y + r * cos(36 * 3.14 / 180));
	p[4].x = (LONG)(m_pts[0].x + r * sin(72 * 3.14 / 180));
	p[4].y = (LONG)(m_pts[0].y - r * cos(72 * 3.14 / 180));
	
	pDC->Polygon(p, 5);    // 繪製多邊形
}



BOOL CPolygon::OnMouseMove(CWnd* pWnd, UINT nFlags, CPoint point)
{
	CClientDC dc(pWnd);
	CGdiObject* pOldPen = dc.SelectStockObject(WHITE_PEN);
	dc.SetROP2(R2_XORPEN);		// XOR pen

	int sz = m_pts.GetSize();
	POINT ptFloat = m_pts[sz - 1];	// 未定之點
	POINT ptFixed = m_pts[sz - 2];	// 已定之點

	POINT star[5];

	dc.SelectObject(GetStockObject(DC_BRUSH));
	dc.SelectObject(GetStockObject(DC_PEN));
	if (m_bFill == TRUE)
	{

		dc.SetDCPenColor(RGB(255, 255, 255) - m_colorLine);
	}
	dc.SetDCBrushColor(m_colorFill);
	//dc.SetBkColor(m_colorFill);
	if (ptFloat.x != ptFixed.x || ptFloat.y != ptFixed.y) // 未定之點 != 已定之點
		for (int i = sz - 2; i < sz - 1; i++) {

			int  r = (int)sqrt(pow((double)(m_pts[i].x - ptFloat.x), 2) + pow((double)(m_pts[i].y - ptFloat.y), 2));
			star[0].x = ptFloat.x;
			star[0].y = ptFloat.y - r;
			star[1].x = (LONG)(ptFloat.x - r * sin(72 * 3.14 / 180));/*極座標*/
			star[1].y = (LONG)(ptFloat.y - r * cos(72 * 3.14 / 180));
			star[2].x = (LONG)(ptFloat.x - r * sin(36 * 3.14 / 180));
			star[2].y = (LONG)(ptFloat.y + r * cos(36 * 3.14 / 180));
			star[3].x = (LONG)(ptFloat.x + r * sin(36 * 3.14 / 180));
			star[3].y = (LONG)(ptFloat.y + r * cos(36 * 3.14 / 180));
			star[4].x = (LONG)(ptFloat.x + r * sin(72 * 3.14 / 180));
			star[4].y = (LONG)(ptFloat.y - r * cos(72 * 3.14 / 180));
			dc.Polygon(star, 5);

		}
	// 繪製新線
	// 繪製新線
	m_pts[sz - 1] = point;// 改變未定點
	for (int i = sz - 2; i < sz - 1; i++) {

		int  r = (int)sqrt(pow((double)(m_pts[i].x - ptFloat.x), 2) + pow((double)(m_pts[i].y - ptFloat.y), 2));
		star[0].x = ptFloat.x;
		star[0].y = ptFloat.y - r;
		star[1].x = (LONG)(ptFloat.x - r * sin(72 * 3.14 / 180));/*極座標*/
		star[1].y = (LONG)(ptFloat.y - r * cos(72 * 3.14 / 180));
		star[2].x = (LONG)(ptFloat.x - r * sin(36 * 3.14 / 180));
		star[2].y = (LONG)(ptFloat.y + r * cos(36 * 3.14 / 180));
		star[3].x = (LONG)(ptFloat.x + r * sin(36 * 3.14 / 180));
		star[3].y = (LONG)(ptFloat.y + r * cos(36 * 3.14 / 180));
		star[4].x = (LONG)(ptFloat.x + r * sin(72 * 3.14 / 180));
		star[4].y = (LONG)(ptFloat.y - r * cos(72 * 3.14 / 180));
		dc.Polygon(star, 5);

	}
	dc.SelectObject(pOldPen);
	return TRUE;

}
	
