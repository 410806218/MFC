﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 產生的 Include 檔案。
// 由 UI3B18PainterrOwnerDraw.rc 使用
//
#define IDC_CURSOR_CROSS                5
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_UI3B18PainterrOwnerDrawTYPE 130
#define ID_WINDOW_MANAGER               131
#define IDC_CURSOR_LBTNDOWN             315
#define IDC_CURSOR1                     316
#define IDC_CURSOR_LBTNUP               316
#define IDB_BITMAP1                     318
#define IDR_TOOLBAR1                    319
#define IDB_BITMAP2                     321
#define IDB_BITMAP3                     322
#define IDB_BITMAP4                     323
#define IDD_DIALOG1                     324
#define IDC_RADIO2                      1001
#define ID_NULL_COM                     1001
#define IDC_RADIO5                      1004
#define IDC_RADIO6                      1005
#define IDC_RADIO7                      1009
#define IDC_RADIO8                      1010
#define IDC_RADIO9                      1011
#define IDC_RADIO10                     1012
#define IDC_RADIO11                     1013
#define IDC_RADIO12                     1014
#define IDC_RADIO13                     1015
#define IDC_RADIO14                     1016
#define IDC_RADIO15                     1018
#define IDC_RADIO16                     1019
#define IDC_RADIO17                     1020
#define IDC_RADIO18                     1021
#define IDC_RADIO19                     1022
#define IDC_RADIO20                     1023
#define IDC_RADIO21                     1024
#define IDC_RADIO22                     1025
#define IDC_RADIO23                     1026
#define IDC_RADIO24                     1027
#define IDC_RADIO25                     1028
#define IDC_RADIO26                     1029
#define IDC_RADIO27                     1030
#define ID_Menu                         32771
#define ID_32777                        32777
#define ID_32778                        32778
#define ID_32779                        32779
#define ID_COMPLETE_GRAPH               32781
#define ID_LINE                         32782
#define ID_RECTANGLE                    32783
#define ID_ELLIPSE                      32784
#define ID_POLYGON                      32785
#define ID_SCRIBBLE                     32786
#define ID_32787                        32787
#define ID_32788                        32788
#define ID_32789                        32789
#define ID_32790                        32790
#define ID_32791                        32791
#define ID_32792                        32792
#define ID_32793                        32793
#define ID_32794                        32794
#define ID_32795                        32795
#define ID_32796                        32796
#define ID_W_0                          32797
#define ID_W_1                          32798
#define ID_W_2                          32799
#define ID_W_3                          32800
#define ID_W_4                          32801
#define ID_W_6                          32802
#define ID_W_8                          32803
#define ID_W_16                         32804
#define ID_Menu32805                    32805
#define ID_Menu32806                    32806
#define ID_32807                        32807
#define ID_32808                        32808
#define ID_32809                        32809
#define ID_32810                        32810
#define ID_LINE_RED                     32811
#define ID_LINE_GREEN                   32812
#define ID_LINE_BLUE                    32813
#define ID_LINE_BLACK                   32814
#define ID_LINE_CHOOSE_COLOR            32815
#define ID_32816                        32816
#define ID_32817                        32817
#define ID_32818                        32818
#define ID_32819                        32819
#define ID_32820                        32820
#define ID_32821                        32821
#define ID_FILL_NONE                    32822
#define ID_FILL_RED                     32823
#define ID_FILL_GREEN                   32824
#define ID_FILL_BLUE                    32825
#define ID_FILL_BLACK                   32826
#define ID_FILL_CHOOSEN                 32827
#define ID_FILL_CHOOSEN_COLOR           32828
#define ID_FILL_CHOOSE_COLOR            32829
#define ID_BUTTON32846                  32846

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        326
#define _APS_NEXT_COMMAND_VALUE         32847
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
