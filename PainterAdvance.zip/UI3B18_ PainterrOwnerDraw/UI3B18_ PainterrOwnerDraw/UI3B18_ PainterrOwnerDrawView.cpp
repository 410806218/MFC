﻿
// UI3B18_ PainterrOwnerDrawView.cpp: CUI3B18PainterrOwnerDrawView 類別的實作
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以定義在實作預覽、縮圖和搜尋篩選條件處理常式的
// ATL 專案中，並允許與該專案共用文件程式碼。
#ifndef SHARED_HANDLERS
#include "UI3B18_ PainterrOwnerDraw.h"
#endif

#include "UI3B18_ PainterrOwnerDrawDoc.h"
#include "UI3B18_ PainterrOwnerDrawView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CUI3B18PainterrOwnerDrawView

IMPLEMENT_DYNCREATE(CUI3B18PainterrOwnerDrawView, CView)

BEGIN_MESSAGE_MAP(CUI3B18PainterrOwnerDrawView, CView)
	// 標準列印命令
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_COMMAND_RANGE(ID_COMPLETE_GRAPH, ID_SCRIBBLE, &CUI3B18PainterrOwnerDrawView::ChangeShape)
	ON_COMMAND_RANGE(ID_W_0, ID_W_16, &CUI3B18PainterrOwnerDrawView::ChangeSIZE)
	//ON_COMMAND_RANGE(ID_COMPLETE_GRAPH, ID_POLY, &CUI3B18PainterrOwnerDrawView::OnCompleteGraph)
	ON_COMMAND_RANGE(ID_FILL_NONE, ID_FILL_CHOOSE_COLOR, &CUI3B18PainterrOwnerDrawView::ChangeFillColor)
	ON_COMMAND_RANGE(ID_LINE_RED, ID_LINE_CHOOSE_COLOR, &CUI3B18PainterrOwnerDrawView::ChangeColor)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()

// CUI3B18PainterrOwnerDrawView 建構/解構

CUI3B18PainterrOwnerDrawView::CUI3B18PainterrOwnerDrawView() noexcept
	: m_nLineWidth(1)
	, m_colorLine(RGB(0, 0, 0))
	, m_bFill(TRUE)
	, m_colorFill(RGB(255, 255, 255))
	, m_pShape(NULL)
	, m_nShapeDrawing(NONE)
{
	// TODO: 在此加入建構程式碼

}

CUI3B18PainterrOwnerDrawView::~CUI3B18PainterrOwnerDrawView()
{
}

BOOL CUI3B18PainterrOwnerDrawView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此經由修改 CREATESTRUCT cs 
	// 達到修改視窗類別或樣式的目的

	return CView::PreCreateWindow(cs);
}

// CUI3B18PainterrOwnerDrawView 繪圖

void CUI3B18PainterrOwnerDrawView::OnDraw(CDC*pDC)
{
	CUI3B18PainterrOwnerDrawDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	// TODO: 在此加入原生資料的描繪程式碼
	int sz = pDoc->m_shapes.GetSize();
	for (int i = 0; i < sz; i++)
		((CShape*)pDoc->m_shapes[i])->Draw(pDC);
	// TODO: 在此加入原生資料的描繪程式碼
}


// CUI3B18PainterrOwnerDrawView 列印

BOOL CUI3B18PainterrOwnerDrawView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 預設的準備列印程式碼
	return DoPreparePrinting(pInfo);
}

void CUI3B18PainterrOwnerDrawView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 加入列印前額外的初始設定
}

void CUI3B18PainterrOwnerDrawView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 加入列印後的清除程式碼
}


// CUI3B18PainterrOwnerDrawView 診斷

#ifdef _DEBUG
void CUI3B18PainterrOwnerDrawView::AssertValid() const
{
	CView::AssertValid();
}

void CUI3B18PainterrOwnerDrawView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CUI3B18PainterrOwnerDrawDoc* CUI3B18PainterrOwnerDrawView::GetDocument() const // 內嵌非偵錯版本
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CUI3B18PainterrOwnerDrawDoc)));
	return (CUI3B18PainterrOwnerDrawDoc*)m_pDocument;
}
#endif //_DEBUG
CShape* CUI3B18PainterrOwnerDrawView::CreateShape(SHAPE shape)
{
	switch (shape) {
	case CG:
		return new CFullyConnectedGraph(m_nLineWidth, m_colorLine);
	case LINE:
		return new CLine(m_nLineWidth, m_colorLine);
	case RECTANGLE:
		return new CRectangle(m_nLineWidth, m_colorLine, m_bFill, m_colorFill);
	case ELLIPSE:
		return new CEllipse(m_nLineWidth, m_colorLine, m_bFill, m_colorFill);
	case POLYGON:
		return new CPolygon(m_nLineWidth, m_colorLine, m_bFill, m_colorFill);
	case SCRIBBLE:
		return new CScribble(m_nLineWidth, m_colorLine);
	default:
		return NULL;
	}
}
void CUI3B18PainterrOwnerDrawView::SaveShape()
{
	CUI3B18PainterrOwnerDrawDoc* pDoc = GetDocument();

	if (!m_pShape->IsValid())
		delete m_pShape;		// 若為無效圖形則刪除之
	else
		pDoc->AddShape(m_pShape);	// 存入Doc中

	m_pShape = NULL;			// 編輯已完成，無編輯中物件實體

	ReleaseCapture();			// 釋放滑鼠
	Invalidate();			// 重新繪製畫面
}

void CUI3B18PainterrOwnerDrawView::OnLButtonDown(UINT nFlags, CPoint point)
{
	if (!m_nShapeDrawing)					// 未選擇繪製任何圖形
		return;

	if (m_pShape == NULL) {					// 無圖形實體，須觸發開始編輯
		m_pShape = CreateShape(m_nShapeDrawing);		// 創造欲編輯之圖形實體
		ASSERT(m_pShape);					// 偵錯用可刪除
		if (!m_pShape->StartEdit(this, nFlags, point)) {	// 創造圖形實體失敗	
			AfxMessageBox(_T("Invalid Shape Attributes"), MB_ICONSTOP | MB_OK);
			delete m_pShape;				// 刪除所創造圖形實體
			m_pShape = NULL;				// 已無編輯中圖形
		}
	}
	else if (!m_pShape->OnLButtonDown(this, nFlags, point))	// 編輯已開始呼叫圖形之訊息處理函數
		SaveShape();					// 儲存編輯完成之圖形 
	SetCursor(LoadCursor(AfxGetInstanceHandle(),
		MAKEINTRESOURCE(IDC_CURSOR_LBTNDOWN)));
	
}
BOOL CUI3B18PainterrOwnerDrawView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	// TODO: 在此加入您的訊息處理常式程式碼和 (或) 呼叫預設值

	if (!m_nShapeDrawing)
		return CView::OnSetCursor(pWnd, nHitTest, message);
	SetCursor(LoadCursor(AfxGetInstanceHandle(),
		MAKEINTRESOURCE(IDC_CURSOR_CROSS)));

	return TRUE;
}

void CUI3B18PainterrOwnerDrawView::OnMouseMove(UINT nFlags, CPoint point)
{
	if (m_pShape == NULL) return;	// 確認圖形編輯中
	if (!m_pShape->OnMouseMove(this, nFlags, point))
		SaveShape();		// 已完成編輯時，存放圖形實體與善後
	SetCursor(LoadCursor(AfxGetInstanceHandle(),
		MAKEINTRESOURCE(IDC_CURSOR_LBTNUP)));

}

void CUI3B18PainterrOwnerDrawView::OnLButtonUp(UINT nFlags, CPoint point)
{
	if (m_pShape == NULL) return;	// 確認圖形編輯中
	if (!m_pShape->OnLButtonUp(this, nFlags, point))
		SaveShape();		// 已完成編輯時，存放圖形實體與善後
	SetCursor(LoadCursor(AfxGetInstanceHandle(),
		MAKEINTRESOURCE(IDC_CURSOR_LBTNUP)));

	
}

void CUI3B18PainterrOwnerDrawView::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	if (m_pShape == NULL) return;	// 確認圖形編輯中
	if (!m_pShape->OnLButtonDblClk(this, nFlags, point))
		SaveShape();		// 已完成編輯時，存放圖形實體與善後
}
void  CUI3B18PainterrOwnerDrawView::ChangeShape(UINT nID)
{

	switch (nID)
	{

	case ID_COMPLETE_GRAPH:
		m_nShapeDrawing =CG;
		break;
	case ID_LINE:
		m_nShapeDrawing =LINE;
		break;
	case ID_RECTANGLE:
		m_nShapeDrawing = RECTANGLE;
		break;
	case ID_ELLIPSE:
		m_nShapeDrawing = ELLIPSE;
		break;
	case ID_POLYGON:
		m_nShapeDrawing = POLYGON;
		break;
	case ID_SCRIBBLE:
		m_nShapeDrawing = SCRIBBLE;
		break;
	case ID_NULL_COM:
		m_nShapeDrawing = NONE;
		break;


	}
}
void  CUI3B18PainterrOwnerDrawView::ChangeColor(UINT nID)
{
	switch (nID)
	{
	case ID_LINE_BLACK:
		m_colorLine = RGB(0, 0, 0);
		break;
	case ID_LINE_RED:
		m_colorLine = RGB(255, 0, 0);
		break;
	case ID_LINE_GREEN:
		m_colorLine = RGB(0, 255, 0);
		break;
	case ID_LINE_BLUE:
		m_colorLine = RGB(0, 0, 255);
		break;
	case ID_LINE_CHOOSE_COLOR:
		CColorDialog m_setClrDlg;
		m_setClrDlg.m_cc.Flags |= CC_FULLOPEN | CC_RGBINIT;
		if (IDOK == m_setClrDlg.DoModal())
		{
			m_colorLine = m_setClrDlg.m_cc.rgbResult;
		}
		break;
	}
}
void CUI3B18PainterrOwnerDrawView::ChangeSIZE(UINT nID)
{
	m_bFill = TRUE;
	switch (nID)
	{
	case ID_W_0:
		
		m_nLineWidth = 0;
		break;
	case ID_W_1:
		m_nLineWidth = 1;
		break;
	case ID_W_2:
		m_nLineWidth = 2;
		break;
	case ID_W_4:
		m_nLineWidth = 4;
		break;
	case ID_W_6:
		m_nLineWidth = 6;
		break;
	case ID_W_8:
		m_nLineWidth = 8;
		break;
	case ID_W_16:
		m_nLineWidth = 16;
		break;
	}
}
void CUI3B18PainterrOwnerDrawView::ChangeFillColor(UINT nID)
{

	switch (nID)
	{
	case ID_FILL_NONE:

		m_colorFill = NULL;
		break;
	case ID_FILL_RED:
		m_colorFill = RGB(0, 255, 255);
		break;
	case ID_FILL_GREEN:
		m_colorFill = RGB(255, 0, 255);
		break;
	case ID_FILL_BLUE:
		m_colorFill = RGB(255, 255, 0);
		break;
	case ID_FILL_BLACK:
		m_colorFill = RGB(255, 255, 255);
		break;
	case ID_FILL_CHOOSE_COLOR:
		CColorDialog m_setClrDlg;
		m_setClrDlg.m_cc.Flags |= CC_FULLOPEN | CC_RGBINIT;
		if (IDOK == m_setClrDlg.DoModal())
		{
			m_colorFill = RGB(255, 255, 255) - m_setClrDlg.m_cc.rgbResult;
		}
		break;
	}
}
// CUI3B18PainterrOwnerDrawView 訊息處理常式
