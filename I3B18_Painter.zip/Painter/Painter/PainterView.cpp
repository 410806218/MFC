﻿
// PainterView.cpp: CPainterView 類別的實作
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以定義在實作預覽、縮圖和搜尋篩選條件處理常式的
// ATL 專案中，並允許與該專案共用文件程式碼。
#ifndef SHARED_HANDLERS
#include "Painter.h"
#endif

#include "PainterDoc.h"
#include "PainterView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CPainterView

IMPLEMENT_DYNCREATE(CPainterView, CView)

BEGIN_MESSAGE_MAP(CPainterView, CView)
	// 標準列印命令
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_KEYDOWN()
	ON_WM_SETCURSOR()
	ON_COMMAND_RANGE(ID_LINE_RED, ID_LINE_CHOOSE_COLOR, &CPainterView::ChangeColor)
	
	ON_UPDATE_COMMAND_UI_RANGE(ID_LINE_RED, ID_LINE_CHOOSE_COLOR, &CPainterView::OnUpdateColor)
	ON_UPDATE_COMMAND_UI_RANGE(ID_W_0, ID_W_16, &CPainterView::OnUpdatesize)
	ON_UPDATE_COMMAND_UI_RANGE(ID_FILL_NONE, ID_FILL_CHOOSE_COLOR, &CPainterView::OnUpdatefill)
	ON_UPDATE_COMMAND_UI_RANGE(ID_COMPLETE_GRAPH, ID_POLY, &CPainterView::OnUpdatepoly)
	ON_COMMAND_RANGE(ID_W_0, ID_W_16, &CPainterView::ChangeSIZE)
	ON_COMMAND_RANGE(ID_COMPLETE_GRAPH, ID_POLY, &CPainterView::OnCompleteGraph)
	ON_COMMAND_RANGE(ID_FILL_NONE, ID_FILL_CHOOSE_COLOR, &CPainterView::ChangeFillColor)
END_MESSAGE_MAP()

// CPainterView 建構/解構

CPainterView::CPainterView() noexcept
	: m_nLineWidth(1)
	, m_colorLine(RGB(0, 0, 0))
	, m_bFill(TRUE)
	, m_colorFill(RGB(255, 255, 255))
{
	// TODO: 在此加入建構程式碼

}

CPainterView::~CPainterView()
{
}

BOOL CPainterView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此經由修改 CREATESTRUCT cs 
	// 達到修改視窗類別或樣式的目的

	return CView::PreCreateWindow(cs);
}

// CPainterView 繪圖

void CPainterView::OnDraw(CDC* pDC)
{
	CPainterDoc* pDoc = GetDocument();

	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: 在此加入原生資料的描繪程式碼

	int sz = pDoc->m_shapes.GetSize();
	if (m_nShapeDrawing == CG)
	{
		for (int i = 0; i < sz; i++)
			((CCompleteGraph*)pDoc->m_shapes[i])->Draw(pDC);
	}
	else if (m_nShapeDrawing == LINE)
	{

		for (int i = 0; i < sz; i++)
			((CCLINE*)pDoc->m_shapes[i])->Draw(pDC);
	}
	else if (m_nShapeDrawing == RECTANGLE)
	{

		for (int i = 0; i < sz; i++)
			((CCRECT*)pDoc->m_shapes[i])->Draw(pDC);
	}
	else if (m_nShapeDrawing == ELLIPSE)
	{

		for (int i = 0; i < sz; i++)
			((CCEILLSPE*)pDoc->m_shapes[i])->Draw(pDC);
	}
	else if (m_nShapeDrawing == POLYGON)
	{

		for (int i = 0; i < sz; i++)
			((CCPOLY*)pDoc->m_shapes[i])->Draw(pDC);
	}
}


// CPainterView 列

BOOL CPainterView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 預設的準備列印程式碼
	return DoPreparePrinting(pInfo);
}

void CPainterView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 加入列印前額外的初始設定
}

void CPainterView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 加入列印後的清除程式碼
}


// CPainterView 診斷

#ifdef _DEBUG
void CPainterView::AssertValid() const
{
	CView::AssertValid();
}

void CPainterView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CPainterDoc* CPainterView::GetDocument() const // 內嵌非偵錯版本
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPainterDoc)));
	return (CPainterDoc*)m_pDocument;
}
#endif //_DEBUG

void CPainterView::OnInitialUpdate()
{
	CView::OnInitialUpdate();

	// TODO: 在此加入特定的程式碼和 (或) 呼叫基底類別
	m_nShapeDrawing = NONE;		// 無任何繪製中圖形
	m_pShape = NULL;			// 無繪製中圖形

}





void CPainterView::OnCompleteGraph(UINT nID)
{
	// TODO: 在此加入您的命令處理常式程式碼
	m_poly = nID;
	switch (nID)
	{
	case ID_COMPLETE_GRAPH:
		m_nShapeDrawing = CG;
		break;
	case ID_STRAIGHT_LINE:
		m_nShapeDrawing = LINE;
		break;
	case ID_RECT:
		m_nShapeDrawing = RECTANGLE;
		break;
	case ID_OVAL:
		m_nShapeDrawing = ELLIPSE;
		break;
	case ID_POLY:
		m_nShapeDrawing = POLYGON;
		break;
	}
}

void CPainterView::OnUpdateCompleteGraph(CCmdUI* pCmdUI)
{
	// TODO: 在此加入您的命令更新 UI 處理常式程式碼
	pCmdUI->SetCheck(m_nShapeDrawing == CG);
}




void CPainterView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: 在此加入您的訊息處理常式程式碼和 (或) 呼叫預設值
// TODO: 在此加入您的訊息處理常式程式碼和 (或) 呼叫預設值
	if (!m_nShapeDrawing)		// 未選擇繪製任何圖形
		return;

	if (m_pShape == NULL) {	// 已選欲繪製圖形，未建立該圖形物件實體
		SetCapture();		// 鎖定滑鼠

		// 根據選定圖形屬性創建圖形物件實體

		m_pShape = new CCompleteGraph(m_nLineWidth, m_colorLine,m_colorFill);
		
		m_pShape->m_pts.Add(point);	// 加入圖形錨點

	}
	m_pShape->m_pts.Add(point);		// 加入未定之次一點

// 滑鼠於鎖定狀態須依狀態設定游標圖形
	SetCursor(AfxGetApp()->LoadCursor(MAKEINTRESOURCE(IDC_CURSOR_LBTNDOWN)));

}


void CPainterView::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: 在此加入您的訊息處理常式程式碼和 (或) 呼叫預設值

	if (m_pShape == NULL) return;

	CClientDC dc(this);
	CGdiObject* pOldPen = dc.SelectStockObject(WHITE_PEN);
	dc.SetROP2(R2_XORPEN);			// XOR pen


	int sz = m_pShape->m_pts.GetSize();
	POINT ptFloat = m_pShape->m_pts[sz - 1];		// 未定之點
	POINT ptFixed = m_pShape->m_pts[sz - 2];		// 已定之點
	// 擦去舊線
	if (m_nShapeDrawing == CG)
	{


		if (ptFloat.x != ptFixed.x || ptFloat.y != ptFixed.y) // 未定之點 != 已定之點
			for (int i = 0; i < sz - 1; i++) {
				dc.MoveTo(ptFloat);
				dc.LineTo(m_pShape->m_pts[i]);
			}
		// 繪製新線	
		m_pShape->m_pts[sz - 1] = point;// 改變未定點
		for (int i = 0; i < sz - 1; i++) {
			dc.MoveTo(point);
			dc.LineTo(m_pShape->m_pts[i]);
		}
	}
	else if (m_nShapeDrawing == LINE)
	{


		if (ptFloat.x != ptFixed.x || ptFloat.y != ptFixed.y) // 未定之點 != 已定之點
			for (int i = sz - 2; i < sz - 1; i++) {
				dc.MoveTo(ptFloat);
				dc.LineTo(m_pShape->m_pts[i]);
			}
		// 繪製新線

		m_pShape->m_pts[sz - 1] = point;// 改變未定點
		for (int i = sz - 2; i < sz - 1; i++) {
			dc.MoveTo(point);
			dc.LineTo(m_pShape->m_pts[i]);

		}


	}
	else if (m_nShapeDrawing == RECTANGLE)
	{
		dc.SelectObject(GetStockObject(DC_BRUSH));
		dc.SelectObject(GetStockObject(DC_PEN));
		if (m_bFill == TRUE)
		{

			dc.SetDCPenColor(RGB(255, 255, 255) - m_colorLine);
		}
		dc.SetDCBrushColor(m_colorFill);
		//dc.SetBkColor(m_colorFill);
		if (ptFloat.x != ptFixed.x || ptFloat.y != ptFixed.y) // 未定之點 != 已定之點
			for (int i = sz - 2; i < sz - 1; i++) {
				dc.Rectangle(ptFloat.x, ptFloat.y, m_pShape->m_pts[i].x, m_pShape->m_pts[i].y);
			}
		// 繪製新線
		// 繪製新線
		m_pShape->m_pts[sz - 1] = point;// 改變未定點
		for (int i = sz - 2; i < sz - 1; i++) {
			dc.Rectangle(point.x, point.y, m_pShape->m_pts[i].x, m_pShape->m_pts[i].y);

		}


	}
	else if (m_nShapeDrawing == ELLIPSE)
	{
		dc.SelectObject(GetStockObject(DC_BRUSH));
		dc.SelectObject(GetStockObject(DC_PEN));
		if (m_bFill == TRUE)
		{

			dc.SetDCPenColor(RGB(255, 255, 255) - m_colorLine);
		}
		dc.SetDCBrushColor(m_colorFill);
		//dc.SetBkColor(m_colorFill);
		if (ptFloat.x != ptFixed.x || ptFloat.y != ptFixed.y) // 未定之點 != 已定之點
			for (int i = sz - 2; i < sz - 1; i++) {
				dc.Ellipse(ptFloat.x, ptFloat.y, m_pShape->m_pts[i].x, m_pShape->m_pts[i].y);
			}
		// 繪製新線
		// 繪製新線
		m_pShape->m_pts[sz - 1] = point;// 改變未定點
		for (int i = sz - 2; i < sz - 1; i++) {
			dc.Ellipse(point.x, point.y, m_pShape->m_pts[i].x, m_pShape->m_pts[i].y);

		}

	}
	else if (m_nShapeDrawing == POLYGON)
	{
		POINT star[5];

		dc.SelectObject(GetStockObject(DC_BRUSH));
		dc.SelectObject(GetStockObject(DC_PEN));
		if (m_bFill == TRUE)
		{

			dc.SetDCPenColor(RGB(255, 255, 255) - m_colorLine);
		}
		dc.SetDCBrushColor( m_colorFill);
		//dc.SetBkColor(m_colorFill);
		if (ptFloat.x != ptFixed.x || ptFloat.y != ptFixed.y) // 未定之點 != 已定之點
			for (int i = sz - 2; i < sz - 1; i++) {
				
				int  r = (int)sqrt(pow((double)(m_pShape->m_pts[i].x - ptFloat.x), 2) + pow((double)(m_pShape->m_pts[i].y - ptFloat.y), 2));
				star[0].x =ptFloat.x;
				star[0].y = ptFloat.y - r;
				star[1].x = (LONG)(ptFloat.x - r * sin(72 * 3.14 / 180));/*極座標*/
				star[1].y = (LONG)(ptFloat.y - r * cos(72 * 3.14 / 180));
				star[2].x = (LONG)(ptFloat.x - r * sin(36 * 3.14 / 180));
				star[2].y = (LONG)(ptFloat.y + r * cos(36 * 3.14 / 180));
				star[3].x = (LONG)(ptFloat.x + r * sin(36 * 3.14 / 180));
				star[3].y = (LONG)(ptFloat.y + r * cos(36 * 3.14 / 180));
				star[4].x = (LONG)(ptFloat.x + r * sin(72 * 3.14 / 180));
				star[4].y = (LONG)(ptFloat.y - r * cos(72 * 3.14 / 180));
				dc.Polygon(star, 5);
	
			}
		// 繪製新線
		// 繪製新線
		m_pShape->m_pts[sz - 1] = point;// 改變未定點
		for (int i = sz - 2; i < sz - 1; i++) {
			
			int  r = (int)sqrt(pow((double)(m_pShape->m_pts[i].x - ptFloat.x), 2) + pow((double)(m_pShape->m_pts[i].y - ptFloat.y), 2));
			star[0].x = ptFloat.x;
			star[0].y = ptFloat.y - r;
			star[1].x = (LONG)(ptFloat.x - r * sin(72 * 3.14 / 180));/*極座標*/
			star[1].y = (LONG)(ptFloat.y - r * cos(72 * 3.14 / 180));
			star[2].x = (LONG)(ptFloat.x - r * sin(36 * 3.14 / 180));
			star[2].y = (LONG)(ptFloat.y + r * cos(36 * 3.14 / 180));
			star[3].x = (LONG)(ptFloat.x + r * sin(36 * 3.14 / 180));
			star[3].y = (LONG)(ptFloat.y + r * cos(36 * 3.14 / 180));
			star[4].x = (LONG)(ptFloat.x + r * sin(72 * 3.14 / 180));
			star[4].y = (LONG)(ptFloat.y - r * cos(72 * 3.14 / 180));
			dc.Polygon(star, 5);

		}

	}
	dc.SelectObject(pOldPen);

}


void CPainterView::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: 在此加入您的訊息處理常式程式碼和 (或) 呼叫預設值

	if (m_pShape)
		SetCursor(AfxGetApp()->LoadCursor(MAKEINTRESOURCE(IDC_CURSOR_LBTNUP)));

}


void CPainterView::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	// TODO: 在此加入您的訊息處理常式程式碼和 (或) 呼叫預設值
	if (m_pShape) {
		int sz = m_pShape->m_pts.GetSize();
		m_pShape->m_pts.RemoveAt(sz - 1);
		if (sz >= 2) {
			CPainterDoc* pDoc = GetDocument();
			pDoc->AddShape(m_pShape);
		}
		else delete m_pShape;
		m_pShape = NULL;
		ReleaseCapture();
	}

}


void CPainterView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: 在此加入您的訊息處理常式程式碼和 (或) 呼叫預設值
	if (nChar != VK_ESCAPE) return;
	if (m_pShape) {
		delete m_pShape;
		m_pShape = NULL;
		ReleaseCapture();
		Invalidate();
	}
	else {
		m_nShapeDrawing = NONE;
		SetCursor(AfxGetApp()->LoadStandardCursor(MAKEINTRESOURCE(IDC_ARROW)));
	}

}


BOOL CPainterView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	// TODO: 在此加入您的訊息處理常式程式碼和 (或) 呼叫預設值

// 滑鼠未鎖定時之游標設定
	if (!m_nShapeDrawing)
		return CView::OnSetCursor(pWnd, nHitTest, message);
	SetCursor(LoadCursor(AfxGetInstanceHandle(),
		MAKEINTRESOURCE(IDC_CURSOR_CROSS)));

	return TRUE;

}


void CPainterView::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{	// storing code
		ar << m_nLineWidth << m_colorLine;
		ar << m_bFill << m_colorFill;

	}
	else
	{	// loading code
		ar >> m_nLineWidth >> m_colorLine;
		ar >> m_bFill >> m_colorFill;
	}
}


void CPainterView::ChangeColor(UINT nID)
{
	m_nColor = nID;
	switch (nID)
	{
	case ID_LINE_BLACK:
		m_colorLine = RGB(0, 0, 0);
		break;
	case ID_LINE_RED:
		m_colorLine = RGB(255, 0, 0);
		break;
	case ID_LINE_GREEN:
		m_colorLine = RGB(0, 255, 0);
		break;
	case ID_LINE_BLUE:
		m_colorLine = RGB(0, 0, 255);
		break;
	case ID_LINE_CHOOSE_COLOR:
		CColorDialog m_setClrDlg;
		m_setClrDlg.m_cc.Flags |= CC_FULLOPEN | CC_RGBINIT;
		if (IDOK == m_setClrDlg.DoModal())
		{
			m_colorLine = m_setClrDlg.m_cc.rgbResult;
		}
		break;
	}
}


void CPainterView::ChangeSIZE(UINT nID)
{
	m_size = nID;
	m_bFill = TRUE;
	switch (nID)
	{
	case ID_W_0:
		m_bFill = FALSE;
		m_nLineWidth = 0;
		break;
	case ID_W_1:
		m_nLineWidth = 1;
		break;
	case ID_W_2:
		m_nLineWidth = 2;
		break;
	case ID_W_4:
		m_nLineWidth = 4;
		break;
	case ID_W_6:
		m_nLineWidth = 6;
		break;
	case ID_W_8:
		m_nLineWidth = 8;
		break;
	case ID_W_16:
		m_nLineWidth = 16;
		break;
	}
}

void CPainterView::ChangeFillColor(UINT nID)
{
	m_nfill = nID;
	switch (nID)
	{
	case ID_FILL_NONE:

		m_colorFill = NULL;
		break;
	case ID_FILL_RED:
		m_colorFill = RGB(0, 255, 255);
		break;
	case ID_FILL_GREEN:
		m_colorFill = RGB(255, 0, 255);
		break;
	case ID_FILL_BLUE:
		m_colorFill = RGB(255, 255, 0);
		break;
	case ID_FILL_BLACK:
		m_colorFill = RGB(255, 255, 255);
		break;
	case ID_FILL_CHOOSE_COLOR:
		CColorDialog m_setClrDlg;
		m_setClrDlg.m_cc.Flags |= CC_FULLOPEN | CC_RGBINIT;
		if (IDOK == m_setClrDlg.DoModal())
		{
			m_colorFill = RGB(255, 255, 255) - m_setClrDlg.m_cc.rgbResult;
		}
		break;
	}
}
void CPainterView::OnUpdateColor(CCmdUI* pCmdUI) {
	pCmdUI->SetCheck(m_nColor == pCmdUI->m_nID);
	
	
}
void CPainterView::OnUpdatesize(CCmdUI* pCmdUI) {
	pCmdUI->SetCheck(m_size == pCmdUI->m_nID);
}
void CPainterView::OnUpdatefill(CCmdUI* pCmdUI) {
	pCmdUI->SetCheck(m_nfill == pCmdUI->m_nID);

}
void CPainterView::OnUpdatepoly(CCmdUI* pCmdUI) {
	pCmdUI->SetCheck(m_poly == pCmdUI->m_nID);

}