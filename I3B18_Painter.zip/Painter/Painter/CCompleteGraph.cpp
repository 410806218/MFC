﻿// CCompleteGraph.cpp: 實作檔案
//

#include "pch.h"
#include "Painter.h"
#include "CCompleteGraph.h"


// CCompleteGraph
IMPLEMENT_SERIAL(CCompleteGraph, CObject, 1)

CCompleteGraph::CCompleteGraph(int w, COLORREF lc, COLORREF cc)
	: m_nLineWidth(w)
	, m_colorLine(lc)
	, m_colorFill(cc)
{
	m_nLineWidth = w;
	m_colorLine = lc;
	m_colorFill = cc;
}

CCompleteGraph::~CCompleteGraph()
{
}



void CCompleteGraph::Draw(CDC* pDC)
{
	CPen pen(PS_SOLID, m_nLineWidth, m_colorLine);
	pDC->SelectObject(GetStockObject(NULL_BRUSH));
	if (m_colorFill != NULL) {
		pDC->SelectObject(GetStockObject(DC_BRUSH));
		pDC->SetDCBrushColor(m_colorFill);
	}
	CGdiObject* pOldPen = pDC->SelectObject(&pen);

	int sz = m_pts.GetSize();
	for (int i = 0; i < sz; i++)
	
		for (int j = i + 1; j < sz; j++)
		{
			pDC->MoveTo(m_pts[i]);
			pDC->LineTo(m_pts[j]);
		}
	

	pDC->SelectObject(pOldPen);
}

// CCompleteGraph 成員函式


void CCompleteGraph::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{	// storing code
		ar << m_nLineWidth << m_colorLine << m_colorFill;

	}
	else
	{	// loading code
		ar >> m_nLineWidth >> m_colorLine >> m_colorFill;

	}
	m_pts.Serialize(ar);
}
