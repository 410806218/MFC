﻿// CCPOLY.cpp: 實作檔案
//

#include "pch.h"
#include "Painter.h"
#include "CCPOLY.h"


// CCEILLSPE
IMPLEMENT_SERIAL(CCPOLY, CObject, 1)
CCPOLY::CCPOLY(int w, COLORREF lc, COLORREF cc)
	: m_nLineWidth(w)
	, m_colorLine(lc)
	,m_colorFill(cc)
{
	m_nLineWidth = w;
	m_colorLine = lc;
	m_colorFill = cc;
}

CCPOLY::~CCPOLY()
{
}



void CCPOLY::Draw(CDC* pDC)
{
	CPen pen(PS_SOLID, m_nLineWidth, m_colorLine);
	pDC->SelectObject(GetStockObject(NULL_BRUSH));
	if (m_colorFill != NULL) {
		pDC->SelectObject(GetStockObject(DC_BRUSH));
		pDC->SetDCBrushColor(RGB(255, 255, 255) - m_colorFill);
	}
	CGdiObject* pOldPen = pDC->SelectObject(&pen);

	int sz = m_pts.GetSize();

	for (int i = 1; i < sz; i++)
	{
		
		POINT star[5];
		int  r = (int)sqrt(pow((double)(m_pts[i].x - m_pts[i - 1].x), 2) + pow((double)(m_pts[i].y - m_pts[i - 1].y), 2));
		star[0].x = m_pts[i - 1].x;
		star[0].y = m_pts[i - 1].y - r;
		star[1].x = (LONG)(m_pts[i - 1].x - r * sin(72 * 3.14 / 180));/*極座標*/
		star[1].y = (LONG)(m_pts[i - 1].y - r * cos(72 * 3.14 / 180));
		star[2].x = (LONG)(m_pts[i - 1].x - r * sin(36 * 3.14 / 180));
		star[2].y = (LONG)(m_pts[i - 1].y + r * cos(36 * 3.14 / 180));
		star[3].x = (LONG)(m_pts[i - 1].x + r * sin(36 * 3.14 / 180));
		star[3].y = (LONG)(m_pts[i - 1].y + r * cos(36 * 3.14 / 180));
		star[4].x = (LONG)(m_pts[i - 1].x + r * sin(72 * 3.14 / 180));
		star[4].y = (LONG)(m_pts[i - 1].y - r * cos(72 * 3.14 / 180));
		pDC->Polygon(star, 5);
		

		//}
	}

	pDC->SelectObject(pOldPen);
}

// CCompleteGraph 成員函式


void CCPOLY::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{	// storing code
		ar << m_nLineWidth << m_colorLine << m_colorFill;

	}
	else
	{	// loading code
		ar >> m_nLineWidth >> m_colorLine >> m_colorFill;

	}
	m_pts.Serialize(ar);
}


// CCEILLSPE 成員函式


// CCPOLY 成員函式
