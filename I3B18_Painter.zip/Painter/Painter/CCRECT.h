#pragma once

// CCRECT �R�O�ؼ�

class CCRECT : public CObject
{
public:
	CCRECT(int w = 1, COLORREF lc = RGB(0, 0, 0), COLORREF cc=RGB(0, 0, 0));
	virtual ~CCRECT();
	DECLARE_SERIAL(CCRECT)

public:
	int m_nLineWidth;
	COLORREF m_colorLine;
	COLORREF m_colorFill;
	CArray<POINT> m_pts;	

public:
	int GetLineWidth() { return m_nLineWidth; }
	void SetLineWidth(int w) { m_nLineWidth = w; }
	COLORREF GetFillColor() { return m_colorFill; }
	COLORREF GetLineColor() { return m_colorLine; }
	void SetLineColor(COLORREF lc) { m_colorLine = lc; }
	void Draw(CDC* pDC);
	virtual void Serialize(CArchive& ar);
};


