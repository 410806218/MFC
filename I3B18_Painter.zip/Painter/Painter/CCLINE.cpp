﻿// CCLINE.cpp: 實作檔案
//

#include "pch.h"
#include "Painter.h"
#include "CCLINE.h"

// CCompleteGraph
IMPLEMENT_SERIAL(CCLINE, CObject, 1)

CCLINE::CCLINE(int w, COLORREF lc)
	: m_nLineWidth(w)
	, m_colorLine(lc)
{
	m_nLineWidth = w;
	m_colorLine = lc;
}

CCLINE::~CCLINE()
{
}



void CCLINE::Draw(CDC* pDC)
{
	CPen pen(PS_SOLID, m_nLineWidth, m_colorLine);
	pDC->SelectObject(GetStockObject(NULL_BRUSH));
	if (m_colorFill != NULL) {
		pDC->SelectObject(GetStockObject(DC_BRUSH));
		pDC->SetDCBrushColor(RGB(255, 255, 255) - m_colorFill);
	}
	CGdiObject* pOldPen = pDC->SelectObject(&pen);
	
	int sz = m_pts.GetSize();
	for (int i = 1; i < sz; i++)
	{
		//for (int j = i + 1; j < sz; j++)
		//{
		pDC->MoveTo(m_pts[i - 1]);
		pDC->LineTo(m_pts[i]);
		//}
	}

	pDC->SelectObject(pOldPen);
}

// CCompleteGraph 成員函式


void CCLINE::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{	// storing code
		ar << m_nLineWidth << m_colorLine;

	}
	else
	{	// loading code
		ar >> m_nLineWidth >> m_colorLine;

	}
	m_pts.Serialize(ar);
}
