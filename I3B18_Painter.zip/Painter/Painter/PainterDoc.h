﻿
// PainterDoc.h: CPainterDoc 類別的介面
//


#pragma once
#include "CCompleteGraph.h"


class CPainterDoc : public CDocument
{
protected: // 僅從序列化建立
	CPainterDoc() noexcept;
	DECLARE_DYNCREATE(CPainterDoc)

// 屬性
public:
	CObArray m_shapes;

// 作業
public:
	void AddShape(CCompleteGraph* pShape);

// 覆寫
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
#ifdef SHARED_HANDLERS
	virtual void InitializeSearchContent();
	virtual void OnDrawThumbnail(CDC& dc, LPRECT lprcBounds);
#endif // SHARED_HANDLERS

// 程式碼實作
public:
	virtual ~CPainterDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 產生的訊息對應函式
protected:
	DECLARE_MESSAGE_MAP()

#ifdef SHARED_HANDLERS
	// 為搜尋處理常式設定搜尋內容的 Helper 函式
	void SetSearchContent(const CString& value);
#endif // SHARED_HANDLERS
};
