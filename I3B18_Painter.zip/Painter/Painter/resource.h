﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 產生的 Include 檔案。
// 由 Painter.rc 使用
//
#define IDC_CURSOR_CROSS                2
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_PainterTYPE                 130
#define ID_WINDOW_MANAGER               131
#define IDC_CURSOR_LBTNDOWN             312

#define IDC_CURSOR_LBTNUP               32771

#define ID_COMPLETE_GRAPH               32100
#define ID_STRAIGHT_LINE                32101
#define ID_RECT                         32102
#define ID_OVAL                         32103
#define ID_POLY                         32104

#define ID_W_0                          32797
#define ID_W_1                          32798
#define ID_W_2                          32799
#define ID_W_4                          32800
#define ID_W_6                          32801
#define ID_W_8                          32802
#define ID_W_16                         32803
#define ID_LINE_RED                     32804
#define ID_LINE_GREEN                   32805
#define ID_LINE_BLUE                    32806
#define ID_32807                        32807
#define ID_LINE_BLACK                   32808
#define ID_LINE_CHOOSE_COLOR            32809
#define ID_FILL_NONE                    32810
#define ID_FILL_RED                     32811
#define ID_FILL_GREEN                   32812
#define ID_FILL_BLUE                    32813
#define ID_FILL_BLACK                   32814
#define ID_FILL_CHOOSE_COLOR            32815


// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        315
#define _APS_NEXT_COMMAND_VALUE         32817
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
