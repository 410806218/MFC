﻿
// PainterView.h: CPainterView 類別的介面
//
#include "CCompleteGraph.h"
#include "CCLINE.h"
#include "CCRECT.h"
#include "CCEILLSPE.h"
#include "CCPOLY.h"
#pragma once


enum SHAPE { NONE = 0, CG, LINE, RECTANGLE, ELLIPSE, POLYGON };


class CPainterView : public CView
{
protected: // 僅從序列化建立
	CPainterView() noexcept;
	DECLARE_DYNCREATE(CPainterView)

	// 屬性
public:
	CPainterDoc* GetDocument() const;

	int m_nLineWidth;		// 線(外框)寬度
	COLORREF m_colorLine;		// 線(外框)顏色
	BOOL m_bFill;			// 是否填充
	COLORREF m_colorFill;		// 填充顏色
	UINT m_nColor;
	UINT m_size;
	UINT m_nfill;
	UINT m_poly;
	SHAPE m_nShapeDrawing;		// 繪製中圖形
	CCompleteGraph* m_pShape;	// 繪製中圖形指標





// 作業
public:
	void OnInitialUpdate();
	void OnCompleteGraph(UINT nID);
	void OnUpdateCompleteGraph(CCmdUI* pCmdUI);



	// 覆寫
public:
	virtual void OnDraw(CDC* pDC);  // 覆寫以描繪此檢視
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

	// 程式碼實作
public:
	virtual ~CPainterView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

	// 產生的訊息對應函式
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void ChangeColor(UINT nID);
	afx_msg void ChangeFillColor(UINT nID);
	afx_msg void ChangeSIZE(UINT nID);
	afx_msg void OnUpdateColor(CCmdUI* pCmdUI);
	afx_msg void OnUpdatesize(CCmdUI* pCmdUI);
	afx_msg void OnUpdatefill(CCmdUI* pCmdUI);
	afx_msg void OnUpdatepoly(CCmdUI* pCmdUI);
	virtual void Serialize(CArchive& ar);
};

#ifndef _DEBUG  // 對 PainterView.cpp 中的版本進行偵錯
inline CPainterDoc* CPainterView::GetDocument() const
{
	return reinterpret_cast<CPainterDoc*>(m_pDocument);
}
#endif

