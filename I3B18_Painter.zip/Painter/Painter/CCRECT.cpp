﻿// CCLINE.cpp: 實作檔案
//

#include "pch.h"
#include "Painter.h"
#include "CCRECT.h"

// CCompleteGraph
IMPLEMENT_SERIAL(CCRECT, CObject, 1)

CCRECT::CCRECT(int w, COLORREF lc, COLORREF cc)
	: m_nLineWidth(w)
	, m_colorLine(lc)
	,m_colorFill(cc)
{
	m_nLineWidth = w;
	m_colorLine = lc;
	m_colorFill = cc;
}

CCRECT::~CCRECT()
{
}



void CCRECT::Draw(CDC* pDC)
{
	CPen pen(PS_SOLID, m_nLineWidth, m_colorLine);
	pDC->SelectObject(GetStockObject(NULL_BRUSH));
	if (m_colorFill != NULL) {
		pDC->SelectObject(GetStockObject(DC_BRUSH));
		pDC->SetDCBrushColor(RGB(255, 255, 255) - m_colorFill);
	}
	CGdiObject* pOldPen = pDC->SelectObject(&pen);

	int sz = m_pts.GetSize();
	for (int i = 1; i < sz; i++)
	{
		//for (int j = i + 1; j < sz; j++)
		//{
		pDC->Rectangle(m_pts[i - 1].x, m_pts[i - 1].y, m_pts[i].x, m_pts[i].y);
		
		//}
	}

	pDC->SelectObject(pOldPen);
}

// CCompleteGraph 成員函式


void CCRECT::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{	// storing code
		ar << m_nLineWidth << m_colorLine << m_colorFill;

	}
	else
	{	// loading code
		ar >> m_nLineWidth >> m_colorLine >> m_colorFill;

	}
	m_pts.Serialize(ar);
}

