﻿// AnalogClock.cpp : 定義應用程式的進入點。
//

#include "framework.h"
#include "AnalogClock.h"
#include"math.h"
#define MAX_LOADSTRING 100
#define PI 3.1415926
// 全域變數:
HINSTANCE hInst;                                // 目前執行個體
WCHAR szTitle[MAX_LOADSTRING];                  // 標題列文字
WCHAR szWindowClass[MAX_LOADSTRING];            // 主視窗類別名稱

// 這個程式碼模組所包含之函式的向前宣告:
ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);

void PrepareDC(HWND hWnd, HDC hdc);
// 繪製坐標軸
void DrawAxes(HDC hdc);
// 設定座標轉換
void SetTransform(HDC hdc, int deg, POINT pos, BOOL rotateFirst = TRUE);
// 繪製圖形---矩形或橢圓
void DrawShape(HDC hdc, int shape);
void DrawShape(HDC hdc, int shape)
{
    HGDIOBJ hPen = CreatePen(PS_SOLID, 12, RGB(139, 69, 19));// 黑筆
    HGDIOBJ hBrush = CreateSolidBrush(RGB(135,206,235));    // 空刷
    HGDIOBJ hOldPen = SelectObject(hdc, hPen);      // 選黑筆存舊筆
    HGDIOBJ hOldBrush = SelectObject(hdc, hBrush);  // 選空刷存舊刷
    Ellipse(hdc, -500, -500, 500, 500);
    SelectObject(hdc, hOldPen);                     // 還原舊筆
    SelectObject(hdc, hOldBrush);                   // 還原舊刷
    DeleteObject(hPen);                             // 資源回收(可免)
    DeleteObject(hBrush);                           // 資源回收(可免)
}

void secpoint(HDC hdc,SYSTEMTIME* pst)
{
    

    int i;

    XFORM xform;
    int deg = 6 * pst->wSecond;

        ZeroMemory(&xform, sizeof(xform));
        double theta = -(deg / 180.0 * PI);
        xform.eM11 = (float)cos(theta);
        xform.eM12 = (float)sin(theta);
        xform.eM21 = (float)-sin(theta);
        xform.eM22 = (float)cos(theta);
        xform.eDx = 0;
        xform.eDy = 0;
        SetWorldTransform(hdc, &xform);
        static POINT pt[3][5] = {
        0, -100,  25, 0, 0, 375,  -25, 0, 0, -100,
        //0, -75, 50, 0, 0, 300, -50, 0, 0, -75,
         0, -100,  25, 0, 0, 350,  -25, 0, 0, -100,
          0, -100,  25, 0, 0, 300,  -25, 0, 0, -100,
            };
        POINT		ptTemp[3][5];
       
    
        Polyline(hdc, pt[0], 5);
        //=======================================
      
        deg = 6*(pst->wMinute)+0.1*( pst->wSecond);
        
        ZeroMemory(&xform, sizeof(xform));
        theta = -(deg / 180.0 * PI);
        xform.eM11 = (float)cos(theta);
        xform.eM12 = (float)sin(theta);
        xform.eM21 = (float)-sin(theta);
        xform.eM22 = (float)cos(theta);
        xform.eDx = 0;
        xform.eDy = 0;
        SetWorldTransform(hdc, &xform);

        Polyline(hdc, pt[1], 5);
    //================================================================
    
        
        
        
            deg = 30 * (pst->wHour) + 0.5 * (pst->wMinute);
        
        //deg = 6 * (pst->wHour)+0.6*(pst->wMinute);

        ZeroMemory(&xform, sizeof(xform));
        theta = -(deg / 180.0 * PI);
        xform.eM11 = (float)cos(theta);
        xform.eM12 = (float)sin(theta);
        xform.eM21 = (float)-sin(theta);
        xform.eM22 = (float)cos(theta);
        xform.eDx = 0;
        xform.eDy = 0;
        SetWorldTransform(hdc, &xform);

        Polyline(hdc, pt[2], 5);

}



void PrepareDC(HWND hWnd, HDC hdc)
{
    SetGraphicsMode(hdc, GM_ADVANCED);
    SetMapMode(hdc, MM_ISOTROPIC);

    RECT rectClient;
    GetClientRect(hWnd, &rectClient);

    SetWindowExtEx(hdc, 1100, 1100, NULL);
    SetViewportExtEx(hdc, rectClient.right, -rectClient.bottom, NULL);
    SetViewportOrgEx(hdc, rectClient.right / 2, rectClient.bottom / 2, NULL);
}
void DrawAxes(HDC hdc)
{
    HGDIOBJ hPen = CreatePen(PS_SOLID, 12,BLACK_BRUSH );       // 黑筆
    HGDIOBJ hBrush = GetStockObject(NULL_BRUSH);   // 黑刷
    HGDIOBJ hOldPen = SelectObject(hdc, hPen);      // 選黑筆存舊筆
    HGDIOBJ hOldBrush = SelectObject(hdc, hBrush);  // 選黑刷存舊刷
    for (int d = 0; d < 360; d += 6) {
        if (d % 30 == 0) {
            HGDIOBJ hPen = CreatePen(PS_SOLID, 12, RGB(139, 69, 19));       // 黑筆
            HGDIOBJ hBrush = GetStockObject(NULL_BRUSH);   // 黑刷
            HGDIOBJ hOldPen = SelectObject(hdc, hPen);      // 選黑筆存舊筆
            HGDIOBJ hOldBrush = SelectObject(hdc, hBrush);  // 選黑刷存舊刷
            MoveToEx(hdc, -500 * cos(d * (3.14 / 180)), 0 + 500 * sin(d * (3.14 / 180)), NULL);                   //水平座標軸
            LineTo(hdc, -400 * cos(d * (3.14 / 180)), 0 + 400 * sin(d * (3.14 / 180)));
            SelectObject(hdc, hOldPen);                     // 還原舊筆
            SelectObject(hdc, hOldBrush);                   // 還原舊刷
            DeleteObject(hPen);                             // 資源回收(可免)
            DeleteObject;
        }
        else {
            HGDIOBJ hPen = CreatePen(PS_SOLID, 1, BLACK_BRUSH);       // 黑筆
            HGDIOBJ hBrush = GetStockObject(NULL_BRUSH);   // 黑刷
            HGDIOBJ hOldPen = SelectObject(hdc, hPen);      // 選黑筆存舊筆
            HGDIOBJ hOldBrush = SelectObject(hdc, hBrush);  // 選黑刷存舊刷
            MoveToEx(hdc, -500 * cos(d * (3.14 / 180)), 0 + 500 * sin(d * (3.14 / 180)), NULL);                   //水平座標軸
            LineTo(hdc, -450 * cos(d * (3.14 / 180)), 0 + 450 * sin(d * (3.14 / 180)));
            SelectObject(hdc, hOldPen);                     // 還原舊筆
            SelectObject(hdc, hOldBrush);                   // 還原舊刷
            DeleteObject(hPen);                             // 資源回收(可免)
            DeleteObject;
        }
    }
    SelectObject(hdc, hOldPen);                     // 還原舊筆
    SelectObject(hdc, hOldBrush);                   // 還原舊刷
    DeleteObject(hPen);                             // 資源回收(可免)
    DeleteObject;
}

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
    _In_opt_ HINSTANCE hPrevInstance,
    _In_ LPWSTR    lpCmdLine,
    _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    // TODO: 在此放置程式碼。

    // 將全域字串初始化
    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_ANALOGCLOCK, szWindowClass, MAX_LOADSTRING);
    MyRegisterClass(hInstance);

    // 執行應用程式初始化:
    if (!InitInstance(hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_ANALOGCLOCK));

    MSG msg;

    // 主訊息迴圈:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int)msg.wParam;
}



//
//  函式: MyRegisterClass()
//
//  用途: 註冊視窗類別。
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_ANALOGCLOCK));
    wcex.hCursor = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wcex.lpszMenuName = MAKEINTRESOURCEW(IDC_ANALOGCLOCK);
    wcex.lpszClassName = szWindowClass;
    wcex.hIconSm = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

//
//   函式: InitInstance(HINSTANCE, int)
//
//   用途: 儲存執行個體控制代碼並且建立主視窗
//
//   註解:
//
//        在這個函式中，我們將執行個體控制代碼儲存在全域變數中，
//        並建立及顯示主程式視窗。
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
    hInst = hInstance; // 將執行個體控制代碼儲存在全域變數中

    HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, nullptr, nullptr, hInstance, nullptr);

    if (!hWnd)
    {
        return FALSE;
    }

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);

    return TRUE;
}

//
//  函式: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  用途: 處理主視窗的訊息。
//
//  WM_COMMAND  - 處理應用程式功能表
//  WM_PAINT    - 繪製主視窗
//  WM_DESTROY  - 張貼結束訊息然後傳回
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    static SYSTEMTIME	stP;
    HDC	hdc;
    SYSTEMTIME	st;
    PAINTSTRUCT	ps;
    int count = 0;
    
    static int shape = 0;               // 0:矩形 1:橢圓
    static bool rotateFirst = TRUE;     // 預設先旋轉後平移
   
 

    switch (message)
    {
    case WM_COMMAND:
    {
        int wmId = LOWORD(wParam);
       
        // 剖析功能表選取項目:
        switch (wmId)
        {
        case IDM_ABOUT:
            DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
            break;
        case IDM_EXIT:
            DestroyWindow(hWnd);
            break;
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
        }
    }
    break;

    case WM_CREATE:{
        SetTimer(hWnd, 1, 1000, NULL);
        GetLocalTime(&st);
        stP = st;
    }
        break;

    case WM_PAINT:
    {
         
        hdc = BeginPaint(hWnd, &ps);
        PrepareDC(hWnd, hdc);
        DrawShape(hdc, shape);
        DrawAxes(hdc);
        secpoint(hdc, &stP);
          
        
        
        EndPaint(hWnd, &ps);
    }
    break;
    case WM_TIMER:
    {   
        GetLocalTime(&st);
       

        hdc = GetDC(hWnd);
        PrepareDC(hWnd, hdc);
        HGDIOBJ hPen = CreatePen(PS_SOLID, 10, RGB(135, 206, 235));
        HGDIOBJ hBrush = SelectObject(hdc, GetStockObject(NULL_BRUSH));
        HGDIOBJ hOldPen = SelectObject(hdc, hPen);      // 選黑筆存舊筆
        HGDIOBJ hOldBrush = SelectObject(hdc, hBrush);  // 選空刷存舊刷

        secpoint(hdc ,&stP);
        SelectObject(hdc, hOldPen);                     // 還原舊筆
        SelectObject(hdc, hOldBrush);                   // 還原舊刷
        DeleteObject(hPen);                             // 資源回收(可免)
        DeleteObject(hBrush);                           // 資源回收(可免)
         hPen = CreatePen(PS_SOLID, 10, RGB(0, 0, 0));
         hBrush = SelectObject(hdc, GetStockObject(NULL_BRUSH));
         hOldPen = SelectObject(hdc, hPen);      // 選黑筆存舊筆
         hOldBrush = SelectObject(hdc, hBrush);  // 選空刷存舊刷
        secpoint(hdc, &st);
        SelectObject(hdc, hOldPen);                     // 還原舊筆
        SelectObject(hdc, hOldBrush);                   // 還原舊刷
        DeleteObject(hPen);                             // 資源回收(可免)
        DeleteObject(hBrush);                           // 資源回收(可免)


        ReleaseDC(hWnd, hdc);
        stP = st;
    }
    break;
    case WM_DESTROY:
        KillTimer(hWnd, 1);
        PostQuitMessage(0);
        
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }

    return 0;
}

// [關於] 方塊的訊息處理常式。
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
    UNREFERENCED_PARAMETER(lParam);
    switch (message)
    {
    case WM_INITDIALOG:
        return (INT_PTR)TRUE;

    case WM_COMMAND:
        if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
        {
            EndDialog(hDlg, LOWORD(wParam));
            return (INT_PTR)TRUE;
        }
        break;
    }
    return (INT_PTR)FALSE;
}
