﻿
// ChildView.cpp: CChildView 类的实现
//

#include "pch.h"
#include "framework.h"
#include "ImageViewer.h"
#include "ChildView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CChildView

CChildView::CChildView()
	: mbmps()
	, mmode(ID_viewa)
	, mmmode(ID_TURNLEFT)

{
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_COMMAND_RANGE(ID_viewa,ID_viewe, &CChildView::OnSetViewMode)
	ON_COMMAND_RANGE(ID_TURNLEFT, ID_UL, &CChildView::OnSetViewMode1)

	ON_UPDATE_COMMAND_UI_RANGE(ID_viewa, ID_viewe, &CChildView::OnUpdateViewMode)

END_MESSAGE_MAP()



// CChildView 消息处理程序

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(nullptr, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), nullptr);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // 繪製的裝置內容 這是看的見的

	// TODO: 在此加入您的訊息處理常式程式碼
	HGDIOBJ hGdiObj = mbmps.GetSafeHandle();
	if (NULL == hGdiObj) return;//若應用程式是空的
	//打下面三行的內容複製到第一航
	typedef void (CChildView::* FUCNTION)(CDC* pPaintDC);

	static FUCNTION fun[] = { &CChildView::OnViewOriginScale,
					&CChildView::OnViewScaleToFitWindow,
					&CChildView::OnViewStretch,
					&CChildView::OnViewUP,
					&CChildView::OnViewLT };


	(this->*fun[mmmode - ID_TURNLEFT])(&dc);


	/*CDC dcBmp;//自己造一個畫布
	dcBmp.CreateCompatibleDC(NULL);//造一個和某一個類型一樣的畫布 null表示和銀幕相同知id//選入bmap bmaps有多大 螢幕有奪大
	CBitmap* pOldBmp = dcBmp.SelectObject(&mbmps);//選了之後會傳回舊的

	BITMAP bmpInfo;
	mbmps.GetBitmap(&bmpInfo);//現在要知道這個圖的大小,需要給定一個傳回位置bmpinfo得到位置

	dc.BitBlt(0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, &dcBmp, 0, 0, SRCCOPY);
	//要把0,0的位置上面 x座標y座標多寬...要準備顯示在 來源dc為dcbmp 要從0,0的位置複製到他0,0的位置 以copy的方式複製
	dcBmp.SelectObject(pOldBmp);//還原選回舊的object
	dcBmp.DeleteDC();
	// 不要呼叫描繪訊息的 CWnd::OnPaint()
	*/
}
void CChildView::OnSetViewMode(UINT id)
{
	id = id - 32460;
	onupdateresourcebitmap(id);
}
void CChildView::OnSetViewMode1(UINT id)
{
	mmmode = id;
	Invalidate();


}
void CChildView::OnUpdateViewMode(CCmdUI* pCmdUI)
{
	pCmdUI->SetCheck(midbmp == (pCmdUI->m_nID)-32460);
}
void CChildView::OnViewOriginScale(CDC* pPaintDC)
{
	// TODO: 在此加入您的命令處理常式程式碼
	CDC dcBmp;
	dcBmp.CreateCompatibleDC(NULL);

	CBitmap* pOldBmp = dcBmp.SelectObject(&mbmps);
	BITMAP bmpInfo;
	mbmps.GetBitmap(&bmpInfo);

	pPaintDC->BitBlt(0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight,
		&dcBmp, 0, 0, SRCCOPY);

	dcBmp.SelectObject(pOldBmp);
	dcBmp.DeleteDC();
}
void CChildView::OnViewStretch(CDC* pPaintDC)
{
	// TODO: 在此加入您的命令處理常式程式碼
	CDC dcBmp;
	dcBmp.CreateCompatibleDC(NULL);

	CBitmap* pOldBmp = dcBmp.SelectObject(&mbmps);
	BITMAP bmpInfo;
	mbmps.GetBitmap(&bmpInfo);

	CRect rect;
	GetClientRect(&rect);

	pPaintDC->StretchBlt(0, 0, rect.Width(), rect.Height(),
		&dcBmp, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY);

	dcBmp.SelectObject(pOldBmp);
	dcBmp.DeleteDC();
}
void CChildView::OnViewScaleToFitWindow(CDC* pPaintDC)
{
	// TODO: 在此加入您的命令處理常式程式碼
	CDC dcBmp;
	dcBmp.CreateCompatibleDC(NULL);

	CBitmap* pOldBmp = dcBmp.SelectObject(&mbmps);
	BITMAP bmpInfo;
	mbmps.GetBitmap(&bmpInfo);
	CRect rect;
	GetClientRect(&rect);

	float scale = ceil(rect.Height() / bmpInfo.bmHeight);
	float width = ceil(bmpInfo.bmWidth * scale); 
	 pPaintDC->StretchBlt((rect.Width() / 2) - (width / 2), 0, width, rect.Height(),
		&dcBmp, 0, 0, bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY);
		
	
	dcBmp.SelectObject(pOldBmp);
	dcBmp.DeleteDC();
}
void CChildView::OnViewUP(CDC* pPaintDC)
{
	// TODO: 在此加入您的命令處理常式程式碼
	CDC dcBmp;
	dcBmp.CreateCompatibleDC(NULL);

	CBitmap* pOldBmp = dcBmp.SelectObject(&mbmps);
	BITMAP bmpInfo;
	mbmps.GetBitmap(&bmpInfo);
	CRect rect;
	GetClientRect(&rect);

	float scale = ceil(rect.Height() / bmpInfo.bmHeight);
	float width = ceil(bmpInfo.bmWidth * scale);
	pPaintDC->StretchBlt((rect.Width() - width) / 2, 0, width, rect.Height(),
		&dcBmp, bmpInfo.bmWidth, 0, -bmpInfo.bmWidth, bmpInfo.bmHeight, SRCCOPY);

	dcBmp.SelectObject(pOldBmp);
	dcBmp.DeleteDC();
}
void CChildView::OnViewLT(CDC* pPaintDC)
{
	// TODO: 在此加入您的命令處理常式程式碼
	CDC dcBmp;
	dcBmp.CreateCompatibleDC(NULL);

	CBitmap* pOldBmp = dcBmp.SelectObject(&mbmps);
	BITMAP bmpInfo;
	mbmps.GetBitmap(&bmpInfo);
	CRect rect;
	GetClientRect(&rect);

	float scale = ceil(rect.Height() / bmpInfo.bmHeight);
	float width = ceil(bmpInfo.bmWidth * scale);
	pPaintDC->StretchBlt((rect.Width() - width) / 2, 0, width, rect.Height(),
		&dcBmp, 0, bmpInfo.bmHeight, bmpInfo.bmWidth, -bmpInfo.bmHeight, SRCCOPY);
	dcBmp.SelectObject(pOldBmp);
	dcBmp.DeleteDC();
}
void CChildView::onupdateresourcebitmap(UINT id)
{
	// TODO: 在此处添加实现代码.
	midbmp = id;
	mbmps.DeleteObject();
	mbmps.LoadBitmap(id);
	Invalidate();
}



