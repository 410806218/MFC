﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 ImageViewer.rc 使用
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_ImageViewerTYPE             130
#define IDB_BITMAP1                     311
#define IDB_BITMAP2                     312
#define IDB_BITMAP3                     313
#define IDB_BITMAP4                     314
#define IDB_BITMAP5                     315
#define ID_viewa                        32771
#define ID_viewb                        32772
#define ID_viewc                        32773
#define ID_viewd                        32774
#define ID_viewe                        32775
#define ID_TURNLEFT                     32794
#define ID_TURNUP                       32795
#define ID_90DEG                        32796
#define ID_TL                           32797
#define ID_UL                           32798
#define ID_BUTTON32804                  32804
#define ID_BUTTON32806                  32806

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        317
#define _APS_NEXT_COMMAND_VALUE         32807
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
