﻿
// ChildView.h: CChildView 类的接口
//


#pragma once


// CChildView 窗口

class CChildView : public CWnd
{
// 构造
public:
	CChildView();

// 特性
public:

// 操作
public:

// 重写
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// 实现
public:
	virtual ~CChildView();

	// 生成的消息映射函数
protected:
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnViewa();
	afx_msg void OnViewb();
	afx_msg void OnViewc();
	CBitmap mbmps;
	UINT mmode;
	UINT mmmode;
	void onupdateresourcebitmap(UINT id);
	afx_msg void OnUpdateViewa(CCmdUI* pCmdUI);
	afx_msg void OnUpdateViewb(CCmdUI* pCmdUI);
	afx_msg void OnUpdateViewc(CCmdUI* pCmdUI);
	UINT midbmp;
	
	void OnSetViewMode(UINT id);
	void OnUpdateViewMode(CCmdUI* pCmdUI);
	void OnSetViewMode1(UINT id);
	void OnUpdateViewMode1(CCmdUI* pCmdUI);
	void OnViewOriginScale(CDC* pPaintDC);
	void OnViewStretch(CDC* pPaintDC);
	void OnViewScaleToFitWindow(CDC* pPaintDC);
	void OnViewUP(CDC* pPaintDC);
	void OnViewLT(CDC* pPaintDC);
	afx_msg void OnViewd();
	afx_msg void OnUpdateViewd(CCmdUI* pCmdUI);
	afx_msg void OnIdViewe();
	afx_msg void OnUpdateIdViewe(CCmdUI* pCmdUI);
	afx_msg void OnViewe();
	afx_msg void OnUpdateViewe(CCmdUI* pCmdUI);
};

