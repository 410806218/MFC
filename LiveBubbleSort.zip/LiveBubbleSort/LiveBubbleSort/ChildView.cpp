﻿
// ChildView.cpp: CChildView 類別的實作
//

#include "pch.h"
#include "framework.h"
#include "LiveBubbleSort.h"
#include "ChildView.h"
#include "CSwapNumberWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif
int idd = 109;
int aa = 10;

// CChildView

CChildView::CChildView()
{
	CSwapNumberWnd::m_nRandDenum = 100;
	CSwapNumberWnd::m_font.CreateFont(48, 0, 0, 0, FW_BOLD, 0,
		0, 0, DEFAULT_CHARSET,
		0, 0, 0, 0, _T("Microsoft Sans Serif"));
}



CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView, CWnd)
	ON_WM_PAINT()
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_MESSAGE(WM_SWAP_REQUEST,&CChildView::OnSwapRequest)

	ON_COMMAND(ID_32772, &CChildView::button1)
	ON_COMMAND(ID_32782, &CChildView::button2)
	ON_COMMAND(ID_32774, &CChildView::button3)
	ON_COMMAND(ID_32775, &CChildView::button4)
	ON_COMMAND(ID_32776, &CChildView::button5)
	ON_COMMAND(ID_32777, &CChildView::button6)
	ON_COMMAND(ID_32778, &CChildView::button7)
	ON_COMMAND(ID_32779, &CChildView::button8)
	ON_COMMAND(ID_32780, &CChildView::button9)
	ON_COMMAND(ID_32781, &CChildView::button10)
END_MESSAGE_MAP()



// CChildView 訊息處理常式

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(nullptr, IDC_ARROW), reinterpret_cast<HBRUSH>(COLOR_WINDOW+1), nullptr);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // 繪製的裝置內容
	
	// TODO: 在此加入您的訊息處理常式程式碼
	
	// 不要呼叫描繪訊息的 CWnd::OnPaint()
}



int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  在此加入特別建立的程式碼

	CRect rect(0, 0, 80, 80);
	for (int i = 0; i < aa; i++) {
		m_wndNums[i].Create(NULL, _T(""),
			WS_CHILD | WS_VISIBLE, rect, this, 100 + i);
		rect.OffsetRect(80, 0);
	}

	return 0;

}


void CChildView::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);

	// TODO: 在此加入您的訊息處理常式程式碼
	Relayout();

}
void CChildView::Relayout()
{
	CRect rect;
	GetClientRect(&rect);
	int x = (rect.Width() - 80 * aa) / 2;
	int y = (rect.Height() - 80) / 2;

	rect = CRect(x, y, x + 80, y + 80);
	for (int i = 0; i < aa; i++) {
		m_wndNums[i].MoveWindow(&rect);
		rect.OffsetRect(80, 0);
	}
}

LRESULT CChildView::OnSwapRequest(WPARAM wParam, LPARAM lParam)
{
	UINT id = wParam;
	TRACE(_T("%d\n"), id);

	if (id >= idd) return 0;
	id -= 100;

	int a, b;
	a = m_wndNums[id].m_nCurrentValue;
	b = m_wndNums[id + 1].m_nCurrentValue;

	m_wndNums[id].m_nCurrentValue = b;
	m_wndNums[id + 1].m_nCurrentValue = a;

	m_wndNums[id].Invalidate();
	m_wndNums[id + 1].Invalidate();
	bool Sucess = true;
	for (int i = 0; i < aa; i++)
	{
		if (m_wndNums[i].m_nCurrentValue > m_wndNums[i + 1].m_nCurrentValue)
		{
			Sucess = false;
		}
	}
	if (Sucess == true)
	{
		int me = AfxMessageBox(LPCTSTR(_T("再玩一次嗎?")), MB_YESNO | MB_ICONQUESTION);
		if (me == IDYES)
		{
			for (int i = 0; i < aa; i++)
			{
				m_wndNums[i].m_nCurrentValue = rand() % 100;
				m_wndNums[i].Invalidate();
			}
			
		}
		else
		{
			ExitProcess(0);
		}
	}

	return 0;
}



void CChildView::button1()
{
	idd = 100;
	aa = 1;
	Relayout();
	OnPaint();
}

void CChildView::button2()
{
	// TODO: 在此加入您的命令處理常式程式碼
	idd = 101;
	aa = 2;
	
	Relayout();
	OnPaint();
}


void CChildView::button3()
{
	// TODO: 在此加入您的命令處理常式程式碼
	idd = 102;
	aa = 3;
	Relayout();
	OnPaint();
}


void CChildView::button4()
{
	// TODO: 在此加入您的命令處理常式程式碼
	idd = 103;
	aa = 4;
	Relayout();
	OnPaint();
}


void CChildView::button5()
{
	// TODO: 在此加入您的命令處理常式程式碼
	idd = 104;
	aa = 5;
	Relayout();
	OnPaint();
}


void CChildView::button6()
{
	// TODO: 在此加入您的命令處理常式程式碼
	idd = 105;
	aa = 6;
	Relayout();
	OnPaint();
}


void CChildView::button7()
{
	// TODO: 在此加入您的命令處理常式程式碼
	idd = 106;
	aa = 7;
	Relayout();
	OnPaint();
}


void CChildView::button8()
{
	// TODO: 在此加入您的命令處理常式程式碼
	idd = 107;
	aa = 8;
	Relayout();
	OnPaint();
}


void CChildView::button9()
{
	// TODO: 在此加入您的命令處理常式程式碼
	idd = 108;
	aa = 9;
	Relayout();
	OnPaint();
}


void CChildView::button10()
{
	// TODO: 在此加入您的命令處理常式程式碼
	idd = 109;
	aa = 10; 
	
	Relayout();
	OnPaint();
}
