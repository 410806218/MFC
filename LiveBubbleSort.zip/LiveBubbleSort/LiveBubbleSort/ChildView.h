﻿
// ChildView.h: CChildView 類別的介面
//
#include "CSwapNumberWnd.h"


#pragma once


// CChildView 視窗

class CChildView : public CWnd
{
public:
	CSwapNumberWnd m_wndNums[10];
	void Relayout();

// 建構
public:
	CChildView();

// 屬性
public:

// 作業
public:

// 覆寫
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// 程式碼實作
public:
	virtual ~CChildView();

	// 產生的訊息對應函式
protected:
	afx_msg void OnPaint();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg LRESULT OnSwapRequest(WPARAM wParam, LPARAM lParam);
	afx_msg void button1();
	afx_msg void button2();
	afx_msg void button3();
	afx_msg void button4();
	afx_msg void button5();
	afx_msg void button6();
	afx_msg void button7();
	afx_msg void button8();
	afx_msg void button9();
	afx_msg void button10();
};

