#pragma once


// CSwapNumberWnd

class CSwapNumberWnd : public CWnd
{
	DECLARE_DYNAMIC(CSwapNumberWnd)

public:
	CSwapNumberWnd();
	virtual ~CSwapNumberWnd();

	// �����ܼ�
public:
	static int m_nRandDenum;
	static CFont m_font;
	int m_nCurrentValue;
	BOOL m_bDown;

protected:
	DECLARE_MESSAGE_MAP()

public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);

//	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
};


